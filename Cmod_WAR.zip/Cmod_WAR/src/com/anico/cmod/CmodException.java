/**
 * 
 */
package com.anico.cmod;

/**
 * @author AD9C49
 *
 */
public class CmodException extends RuntimeException {
	
	private String msg = "";
	
	public CmodException () {
		
	}
	
	public CmodException(String msg) {
		this.msg = msg;
	}
	
	public String getMessage() {
		return msg;
	}
}
