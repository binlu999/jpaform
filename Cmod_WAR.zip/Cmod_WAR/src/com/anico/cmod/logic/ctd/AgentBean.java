package com.anico.cmod.logic.ctd;

import static com.anico.cmod.portlet.CmodPortletConstants.LOGCMOD;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Iterator;

/**
 * POJO that represents an Agent that is used in the downline tab in the front
 * end
 * 
 * @author AD9C62
 * 
 */
public class AgentBean implements Serializable, Comparable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String firstName;

	private String lastName;

	private String logonId;

	private String email;

	private String fullName;

	/**
	 * Constructor wiht instance fields
	 * 
	 * @param firstName
	 * @param lastName
	 * @param logonId
	 * @param email
	 */
	public AgentBean(String firstName, String lastName, String logonId,
			String email) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.fullName = firstName + " " + lastName;
		this.logonId = logonId;
		this.email = email;
	}

	/**
	 * Default constructor
	 * 
	 */
	public AgentBean() {
	}

	/** **** GETTER METHODS ***** */
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.lastName = fullName;
	}	
	
	public void buildFullName() {
		fullName = firstName + " " + lastName;
	}
	
	public String getLogonId() {
		return logonId;
	}

	/** **** SETTER METHODS ***** */
	public void setLogonId(String logonId) {
		this.logonId = logonId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Implementation of the toString method using reflection
	 */
	public String toString() {
		StringBuilder result = new StringBuilder();
		String newLine = System.getProperty("line.separator");

		result.append(this.getClass().getName());
		result.append(" Object {");
		result.append(newLine);

		// determine fields declared in this class only (no fields of
		// superclass)
		Field[] fields = this.getClass().getDeclaredFields();

		// print field names paired with their values
		for (Iterator iter = Arrays.asList(fields).iterator(); iter.hasNext();) {
			Field field = (Field) iter.next();
			result.append("  ");
			try {
				result.append(field.getName());
				result.append(": ");
				// requires access to private field:
				result.append(field.get(this));
			} catch (IllegalAccessException ex) {
				LOGCMOD.warn(ex);
			}
			result.append(newLine);

		}

		result.append("}");

		return result.toString();
	}

	public int compareTo(Object obj) {
		AgentBean agent = (AgentBean) obj;
		int deptComp = firstName.compareTo(agent.getFirstName());

		return ((deptComp == 0) ? lastName.compareTo(agent.getLastName())
				: deptComp);
	}

	public boolean equals(Object obj) {
		if (!(obj instanceof AgentBean)) {
			return false;
		}
		AgentBean agent = (AgentBean) obj;
		return firstName.equals(agent.getFirstName())
				&& lastName.equals(agent.getLastName());
	}

	public int hashCode() {
		return 0;
	}

}
