package com.anico.cmod.logic.ctd;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import com.anico.dasd.ldap.AgentInformationFromLDAP;

import static com.anico.cmod.portlet.CmodPortletConstants.*;

/**
 * Provides utilities to the application
 * 
 * @author AD9C62
 * 
 */
public class CTDUtils {


	public static final String PDF_EXTENSION = "PDF";

	static final List MARKETING_AREAS = new ArrayList();
	static {

		MARKETING_AREAS.add("MLM");
		MARKETING_AREAS.add("SLAICO");
		MARKETING_AREAS.add("IMO");
		MARKETING_AREAS.add("TERM");

	}

	/**
	 * Formats a standard date (MM/dd/yyyy) into the control-D's date format
	 * (dd/MM/yyyy)
	 * 
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static String formatToCTDDate(String date) throws ParseException {

		// checking null date
		if (date != null && !date.equalsIgnoreCase("")) {

			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

			Date tempDate = (Date) formatter.parse(date);

			formatter = new SimpleDateFormat("dd/MM/yyyy");

			date = formatter.format(tempDate);
		} else {
			date = "";
		}

		return date;
	}

	/**
	 * Formats a control-D date (dd/MM/yyyy) into a standard date format
	 * (MM/dd/yyyy)
	 * 
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static String formatToStandardDate(String date)
			throws ParseException {

		// checking null date
		if (date != null && !date.equalsIgnoreCase("")) {
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

			Date tempDate = (Date) formatter.parse(date);

			formatter = new SimpleDateFormat("MM/dd/yyyy");

			date = formatter.format(tempDate);
		} else {
			date = "";
		}

		return date;
	}

	/**
	 * Returns the agency code that matches the marketing area
	 * 
	 * company code and agency code mapping from marketing areas Company 101,
	 * agency OA = MLM, IMG Company 106, agency SL = SLAICO
	 */
	public static String getAgencyCode(String mktArea) {
		String agencyCode = "";
		if (mktArea == null) {
			agencyCode = "";
		} else if (MKT_IMO.equals(mktArea)) {
			agencyCode = "OA";
		} else if (MKT_MLM.equals(mktArea)) {
			agencyCode = "OA";
		} else if (MKT_SLAICO.equals(mktArea)) {
			agencyCode = "SL";
		} else if (MKT_TERM.equals(mktArea)) {
			agencyCode = "OA";
		} else {
			; // do nothing
		}

		return agencyCode;
	}

	/**
	 * Returns the company code that matches the marketing area
	 * 
	 * company code and agency code mapping from marketing areas Company 101,
	 * agency OA = MLM, IMG Company 106, agency SL = SLAICO
	 */
	public static String getCompanyCode(String marketingArea) {
		String companyCode = "";
		if (marketingArea == null) {
			companyCode = "";
		} else if (MKT_IMO.equals(marketingArea)) {
			companyCode = "101";
		} else if (MKT_MLM.equals(marketingArea)) {
			companyCode = "101";
		} else if (MKT_SLAICO.equals(marketingArea)) {
			companyCode = "106";
		} else if (MKT_TERM.equals(marketingArea)) {
			companyCode = "101";
		}else {
			; // do nothing
		}
		return companyCode;
	}

	public static Hashtable<String,String> getMultiCodes(AgentInformationFromLDAP agent) {
		Hashtable<String,String> codes = new Hashtable<String,String>();

		List groups = agent.getList("GROUPS");

		for (Iterator iter = groups.iterator(); iter.hasNext();) {
			String group = (String) iter.next();

			if (MARKETING_AREAS.contains(group)) {
				String companyCode = getCompanyCode(group);
				String agencyCode = getAgencyCode(group);

				if (!codes.containsKey(companyCode)) {
					codes.put(companyCode, agencyCode);
				}
			}

		}

		return codes;
	}


	/**
	 * Returns true if the provided extension is "PDF"
	 * 
	 * @param extension
	 * @return true if extension is "PDF"; false otherwise
	 */
	public static boolean filterPDFReports(String extension) {
		boolean isPDF = false;

		if (PDF_EXTENSION.equalsIgnoreCase(extension)) {
			isPDF = true;
		}

		return isPDF;

	}

}
