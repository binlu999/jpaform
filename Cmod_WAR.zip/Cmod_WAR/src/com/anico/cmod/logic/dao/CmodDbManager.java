package com.anico.cmod.logic.dao;

import java.sql.SQLException;


import com.anico.cmod.portlet.CmodPortletConfig;
import com.anico.dasd.CompoundProperty;
import com.anico.dasd.DASDConfigurationException;
import com.anico.dasd.Environment;
import com.anico.dasd.J2CDbManager;
import com.anico.dasd.ServletConfigReader;

import static com.anico.cmod.portlet.CmodPortletConstants.*;


//  this is for debug only
// import com.microsoft.sqlserver.jdbc.Sqlserverdriver;
public class CmodDbManager {
	
	private static String dataMartDbManagerName = CmodPortletConfig.getDbDataMartName();

	
	/**
	 * Gets a handle to the weclaims db manager
	 * @return
	 * @throws DASDConfigurationException
	 * @throws SQLException
	 */
	public static J2CDbManager getDataMartDbManager()
	throws DASDConfigurationException, SQLException {			
		LOGCMOD.info("getting datamart j2c db manager for:"+dataMartDbManagerName);	
		return new J2CDbManager(dataMartDbManagerName);
	}



	private static  void printClassPath(Class c) {
		LOGCMOD.info(c.getName() + " is loaded from " +
				  c.getProtectionDomain().getCodeSource().getLocation());
	  }
}

