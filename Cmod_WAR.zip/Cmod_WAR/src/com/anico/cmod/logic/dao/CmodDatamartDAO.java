/**
 * 
 */
package com.anico.cmod.logic.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import com.anico.cmod.logic.ctd.AgentBean;
import com.anico.cmod.logic.dao.CmodDbManager;
import com.anico.dasd.J2CDbManager;

import static com.anico.cmod.portlet.CmodPortletConstants.*;
import static com.anico.cmod.portlet.CmodUtils.*;

/**
 * @author AD9C49
 *
 */
public class CmodDatamartDAO {
	
	
	public String getAgentEmailAddr(String agentId) 
	{
		String emailAddr = null;
		
		J2CDbManager dbMgr = null;

        
        String query = " SELECT EMAIL_ADDR FROM DB2TAB.TRAAGID "
        		+ " WHERE LOGON_ID = ? ";
				
        LOGCMOD.debug("running query:"+query);
				
		try {
			
			dbMgr = CmodDbManager.getDataMartDbManager();
			
			if (dbMgr == null) {
				LOGCMOD.error("could not get datamart dbmanager object");
				return emailAddr;
			}
			
			dbMgr.setPrepareStatement(query);
			dbMgr.setPrepareValue(1,agentId);
			
			ResultSet rs = dbMgr.executePrepareStatement();

			if ((rs != null) && (rs.next())) {
				
				emailAddr = StringUtils.trim(rs.getString("EMAIL_ADDR"));
				LOGCMOD.info("email address found is:"+emailAddr+" for:"+agentId);			                							
				
			} else {
				LOGCMOD.info("email address not found for:"+agentId);
			}
			
			if (rs != null) {
				rs.close();
			}						
		} catch (Exception e) {
			LOGCMOD.error("error getEmailAddr  msg:"+e.getMessage());
			e.printStackTrace();
		} finally {
			if (dbMgr != null) {
				try {
					dbMgr.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
				
		return emailAddr;
	}

	
	public boolean isAssociate(String agentId) 
	{
		boolean associateF = false;
		agentId = StringUtils.trimToEmpty(agentId);
		if (StringUtils.isEmpty(agentId)) {
			return true;
		}
				
		associateF = lookupTraasocForAssociate(agentId);
				
		return associateF;				
	}
	
	
	public boolean lookupTraasocForAssociate(String agentId) {
		boolean associateF = false;
		
		agentId = StringUtils.trimToEmpty(agentId);
		
		J2CDbManager dbMgr = null;

        
        String query = " SELECT LOGON_ID FROM DB2TAB.TRAASOC "
        		+ " WHERE LOGON_ID = ? ";
				
        LOGCMOD.debug("running query:"+query+"["+agentId+"]");
				
		try {
			
			dbMgr = CmodDbManager.getDataMartDbManager();
			
			if (dbMgr == null) {
				LOGCMOD.warn("could not get datamart dbmanager object");
				LOGCMOD.info("defaulting assoc record to true for:"+agentId);
				return true;
			}
			
			dbMgr.setPrepareStatement(query);
			dbMgr.setPrepareValue(1,agentId);
			
			ResultSet rs = dbMgr.executePrepareStatement();

			if ((rs != null) && (rs.next())) {				
				LOGCMOD.info("assoc record found for:"+agentId);
				associateF = true;				
			} else {
				LOGCMOD.info("assoc record not found for:"+agentId);
			}
			
			if (rs != null) {
				rs.close();
			}						
		} catch (Exception e) {
			LOGCMOD.error("error assoc lookup  msg:"+e.getMessage());
			e.printStackTrace();
		} finally {
			if (dbMgr != null) {
				try {
					dbMgr.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
				
		return associateF;

	}
	
	
	public boolean lookupTraagidForAssociate(String agentId) 
	{
		boolean associateF = true;
		String associateStr = null;
		
		agentId = StringUtils.trimToEmpty(agentId);
		
		J2CDbManager dbMgr = null;

        
        String query = " SELECT LOGON_ID,ASSOC_SGNL FROM DB2TAB.TRAAGID "
        		+ " WHERE LOGON_ID = ? ";
				
        LOGCMOD.debug("running query:"+query+"["+agentId+"]");
				
		try {
			
			dbMgr = CmodDbManager.getDataMartDbManager();
			
			if (dbMgr == null) {
				LOGCMOD.error("could not get datamart dbmanager object");
				LOGCMOD.info("defaulting associateF to true for:"+agentId);
				return true;
			}
			
			dbMgr.setPrepareStatement(query);
			dbMgr.setPrepareValue(1,agentId);
			
			ResultSet rs = dbMgr.executePrepareStatement();

			if ((rs != null) && (rs.next())) {				
				associateStr = StringUtils.trim(rs.getString("ASSOC_SGNL"));
				LOGCMOD.info("assoc_sgnl  found is:"+associateStr+" for:"+agentId);
				associateF = false;
				if (("Y".equals(associateStr)) || ("y".equals(associateStr))) {
					associateF = true;
				}				
			} else {
				LOGCMOD.info("traagid record not found for:"+agentId);
			}
			
			if (rs != null) {
				rs.close();
			}						
		} catch (Exception e) {
			LOGCMOD.error("error lookuptraagid  msg:"+e.getMessage());
			e.printStackTrace();
		} finally {
			if (dbMgr != null) {
				try {
					dbMgr.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
				
		return associateF;
	}

	
	
	
	// NEW
	private static final String HIERARCHY_SIGNAL_SQL = "select a.hier_sgnl from db2tab.traagid a where a.ssn_no= ?";

	/*
	 select count(*) from db2tab.toacont
where nxt_levl_ssn_no = <ssn>
and (finalled_date is null or finalled_date > current date)

	 */
	private static final String CONTRACT_MANAGER_CHECK_SQL = " select count(*) from db2tab.toacont "
			+ " where nxt_levl_ssn_no = ? "
			+ " and (finalled_date is null or finalled_date > current date)";
	
	/**
	 * Return true if the provided SSN is a manager
	 * 
	 * @param manager
	 * @param ssn
	 * @return
	 * @throws SQLException
	 */
	public boolean isManager(String ssn)  {
		boolean isManagerF = false;
		J2CDbManager dbMgr = null;
		
		if (StringUtils.isEmpty(ssn)) {
			return false;
		}

        String query = CONTRACT_MANAGER_CHECK_SQL;
        LOGCMOD.debug("running query:"+query);
				
		try {
			
			dbMgr = CmodDbManager.getDataMartDbManager();
			
			if (dbMgr == null) {
				LOGCMOD.error("could not get datamart dbmanager object");
				return false;
			}
			
			dbMgr.setPrepareStatement(query);
			dbMgr.setPrepareValue(1,ssn);
			
			ResultSet rs = dbMgr.executePrepareStatement();
			
			
			Integer rtnCountVal = null;
			if ((rs != null) && (rs.next())) {
				rtnCountVal = rs.getInt(1);
				LOGCMOD.info("count db value:"+rtnCountVal);				
			} else {				
				LOGCMOD.info("no count db value found");
			}
			
			if (rtnCountVal != null) {
				if (rtnCountVal > 0) {
					isManagerF = true;
				}
			}
						
			LOGCMOD.info("isManagerF result:"+isManagerF);

			if (rs != null) {
				rs.close();
			}
			
		} catch (Exception e) {
			LOGCMOD.error("error getEmailAddr  msg:"+e.getMessage());
			e.printStackTrace();
		} finally {
						
			if (dbMgr != null) {
				try {
					dbMgr.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
				

		return isManagerF;
	}
	
	  // new implementation. Excludes beneficiaries from MLM downline
	  private static final String GET_DOWNLINE_SQL = "select distinct agid.ssn_no, agid.logon_id, agnt.first_name_text, "
	      + "agnt.last_name_text, agid.email_addr "
	      + "from db2tab.traagid agid "
	      + "inner join db2tab.toahier hier "
	      + "on agid.ssn_no = hier.ssn_no "
	      + "inner join db2tab.toaagnt agnt "
	      + "on hier.ssn_no = agnt.ssn_no "
	      + "inner join db2tab.toacont cont1 "
	      + "on agid.ssn_no = cont1.ssn_no "
	      + "inner join db2tab.toacont cont2 "
	      + "on agid.ssn_no = cont2.ssn_no "
	      + "where agnt.company_code = ? "
	      + "and agnt.agency_code = ? "
	      + "and hier.mgr_ssn_no = ? "
	      + "and (hier.hier_stop_date is null "
	      + "or hier.hier_stop_date > current date) "
	      + "and cont1.type_cont_code <> 'B' "
	      + "and cont1.type_qual_code <> 'N' "
	      + "and cont2.type_cont_code <> '$' "
	      + "and cont2.type_qual_code <> '$' "
	      + "order by agnt.last_name_text, agnt.first_name_text "
	      + "for fetch only";
	  
	  
	  /**
	   * Return a list of agents that belong to the downline of the provided SSN
	   * 
	   * @param manager
	   * @param ssn
	   * @param companyCode
	   * @param agencyCode
	   * @return
	   * @throws SQLException
	   */
	  public List<AgentBean> getDownline(String ssn, String companyCode, String agencyCode) {
	    List<AgentBean> downline = new ArrayList<AgentBean>();
	
		J2CDbManager dbMgr = null;

        String query = GET_DOWNLINE_SQL;				
        LOGCMOD.debug("running query:"+query);
				
		try {
			
			dbMgr = CmodDbManager.getDataMartDbManager();
			
			if (dbMgr == null) {
				LOGCMOD.error("could not get datamart dbmanager object");
				return downline;
			}
			
			dbMgr.setPrepareStatement(query);
		    dbMgr.setPrepareValue(1, companyCode);
		    dbMgr.setPrepareValue(2, agencyCode);
		    dbMgr.setPrepareValue(3, ssn);
			
			ResultSet rs = dbMgr.executePrepareStatement();
			
			int count = 0;
		    while (rs.next()) {
		    	count++;
		        AgentBean agent = new AgentBean();
		        agent.setLogonId(StringUtils.trimToEmpty(rs.getString("LOGON_ID")));
		        agent.setFirstName(StringUtils.trimToEmpty(rs.getString("FIRST_NAME_TEXT")));
		        agent.setLastName(StringUtils.trimToEmpty(rs.getString("LAST_NAME_TEXT")));
		        agent.buildFullName();
		        agent.setEmail(StringUtils.trimToEmpty(rs.getString("EMAIL_ADDR")));
		     		        
		        downline.add(agent); 
		        
		        // debug only
		        // if (count == 3) {break;} 
		        		        		   
		      }
			
			if (rs != null) {
				rs.close();
			}						
		} catch (Exception e) {
			LOGCMOD.error("error getEmailAddr  msg:"+e.getMessage());
			e.printStackTrace();
		} finally {
			if (dbMgr != null) {
				try {
					dbMgr.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	    	    
	    return downline;
	  }	  
	  
	  
	  
		public List<AgentBean> getDownline(String ssn, Hashtable<String,String> codes) {

			Set<AgentBean> downlineSet = new LinkedHashSet<AgentBean>();

			Iterator<Entry<String,String>> it = codes.entrySet().iterator();

			while (it.hasNext()) {
				Entry<String,String> entry = it.next();
				String companyCode = entry.getKey();
				String agencyCode = entry.getValue();

				List<AgentBean> list = getDownline(ssn, companyCode, agencyCode); 
				downlineSet.addAll(list);
			}

		   List<AgentBean> list = new ArrayList<AgentBean>(downlineSet);
			
		   return list;
		}	  
	
	
}

