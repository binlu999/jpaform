package com.anico.cmod.beans;

public class ViewReportsOnStartBean {
	
	boolean appCallF = false;
	
	private String appName = "";
	private String submitType = "";
	
	private String category = "";
	private String policynum = "";
	private String reportName = "";
	
	
	public ViewReportsOnStartBean(String appName,String submitType) {
		this.appName = appName;
		this.submitType = submitType;
	}
	
	
	public boolean isAppCallF() {
		return appCallF;
	}
	public void setAppCallF(boolean appCallF) {
		this.appCallF = appCallF;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getSubmitType() {
		return submitType;
	}
	public void setSubmitType(String submitType) {
		this.submitType = submitType;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPolicynum() {
		return policynum;
	}
	public void setPolicynum(String policynum) {
		this.policynum = policynum;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	
	
	
}
