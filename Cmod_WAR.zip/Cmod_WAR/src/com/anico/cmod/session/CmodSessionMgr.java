package com.anico.cmod.session;

import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;


import static com.anico.cmod.portlet.CmodPortletConstants.*;
import static com.anico.cmod.portlet.CmodUtils.*;

public class CmodSessionMgr {
	
	public static CmodSessionBean getCmodSessionBean(String uid,PortletRequest request) {
		PortletSession session = request.getPortletSession(false);
		CmodSessionBean sessionBean = null;
		
		if (session == null) {
			LOGCMOD.info("CmodSession: NO session found for user:"+uid);					
		} else {
			sessionBean = (CmodSessionBean)session.getAttribute("cmodSessionBean",PortletSession.APPLICATION_SCOPE);
			if (sessionBean == null) {
				LOGCMOD.info("CmodSession: NO session bean found for user:"+uid);
			} else {
				LOGCMOD.info("CmodSession: YES session bean found for user:"+uid);
			}
		}
		
		return sessionBean;
	}
	
	
	public static CmodSessionBean createCmodSessionBean(String uid,PortletRequest request) {
		LOGCMOD.info("CmodSession: Creating session bean for user:"+uid);
		PortletSession session = request.getPortletSession(true);
		CmodSessionBean sessionBean = new CmodSessionBean();
		session.setAttribute("cmodSessionBean", sessionBean,PortletSession.APPLICATION_SCOPE);
		
		return sessionBean;
	}
	
	
	
	
	
	
	

}
