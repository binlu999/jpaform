package com.anico.cmod.session;

public class CmodSessionBean {
	
	private String uid = null;
	private String userName = null;
	private String marketingArea = null;
	private String ssn = null;
	private Boolean managerFlag = null;
	private String userType = null;
	
	
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMarketingArea() {
		return marketingArea;
	}
	public void setMarketingArea(String marketingArea) {
		this.marketingArea = marketingArea;
	}
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public Boolean getManagerFlag() {
		return managerFlag;
	}
	public void setManagerFlag(Boolean managerFlag) {
		this.managerFlag = managerFlag;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	
	
	

}
