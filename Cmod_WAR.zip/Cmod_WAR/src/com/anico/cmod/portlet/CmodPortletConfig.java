package com.anico.cmod.portlet;

import static com.anico.cmod.portlet.CmodPortletConstants.CONFIG_FILE_NAME;
import static com.anico.cmod.portlet.CmodPortletConstants.DB_CONFIG_NAME_DATA_MART;
import static com.anico.cmod.portlet.CmodPortletConstants.LOGCMOD;

import com.anico.dasd.CompoundProperty;
import com.anico.dasd.Environment;
import com.anico.dasd.ServletConfigReader;


import static com.anico.cmod.portlet.CmodPortletConstants.*;

public class CmodPortletConfig {

	private final static String CONFIG_TAG_DB_DATA_MART_NAME = "dataMartDbManagerName";
	private final static String CONFIG_TAG_PDF_SERVICE_URL = "pdfServiceUrl";
	private final static String CONFIG_TAG_CMOD_SOAP_SERVICE_ENDPOINT_URL = "cmodSoapServiceEndpointUrl";
	private final static String DEFAULT_NOT_LOADED_VALUE = "NOT_LOADED_CHECK_CONFIG"; 
	
	
	private static String DB_DATA_MART_NAME = DEFAULT_NOT_LOADED_VALUE;
	private static String PDF_SERVICE_URL = DEFAULT_NOT_LOADED_VALUE;
	private static String CMOD_SOAP_SERVICE_ENDPOINT_URL = DEFAULT_NOT_LOADED_VALUE;
	

	static {
		try {
			CompoundProperty config = new ServletConfigReader(false)
					.readAndGetConfig(CONFIG_FILE_NAME);
			
			if (config == null) {
				LOGCMOD.error("Cmod config handle is null");
			} else {
				LOGCMOD.info("Got handle to cmod config");
			}
			
			String envStr = Environment.getEnvironmentString();
			LOGCMOD.info("Cmod Manager Environment is:"+envStr);
			
			DB_DATA_MART_NAME = config.getSimpleString(CONFIG_TAG_DB_DATA_MART_NAME);	
			LOGCMOD.info("db data mart dsn name is:"+DB_DATA_MART_NAME);			
			
			
			PDF_SERVICE_URL = config.getSimpleString(CONFIG_TAG_PDF_SERVICE_URL);	
			LOGCMOD.info("pdf service url is:"+PDF_SERVICE_URL);		
						
			CMOD_SOAP_SERVICE_ENDPOINT_URL = config.getSimpleString(CONFIG_TAG_CMOD_SOAP_SERVICE_ENDPOINT_URL);	
			LOGCMOD.info("cmod soap service endpoint url is:"+CMOD_SOAP_SERVICE_ENDPOINT_URL);		
			
			
		} catch (Exception e) {
			 LOGCMOD.error("exception in cmod config load:"+e.getMessage());
			 e.printStackTrace();
		} finally {
			LOGCMOD.info("cmod config loaded");
		}
	}
	
	public static String getDbDataMartName() {
		return DB_DATA_MART_NAME;
	}
	
	public static String getPdfServiceUrl() {
		return PDF_SERVICE_URL;
	}
	
	public static String getCmodSoapServiceEndpointUrl() {
		return CMOD_SOAP_SERVICE_ENDPOINT_URL;
	}
	
	
}
