package com.anico.cmod.portlet;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;
import javax.portlet.ResourceRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;

import com.anico.cmod.logic.dao.CmodDatamartDAO;

import static com.anico.cmod.portlet.CmodPortletConstants.*;

public class CmodUtils {

	public static void main(String[] args) {
	}


	public static String getParamValue(PortletRequest request,String paramName) {
		String paramVal = request.getParameter(paramName);
		paramVal = StringUtils.trimToEmpty(paramVal);
		// LOGCMOD.debug("server side param "+paramName + " value is:"+paramVal);

		return paramVal;
	}

	public static String getUrlEncodedValue(String value) {
		String urlEncodedValue = value;
		try {
			urlEncodedValue = URLEncoder.encode(value,"UTF-8");
		} catch (Exception e) {
			LOGCMOD.warn("error in converting to url encoded value for:"+value);
		} finally {
			return urlEncodedValue;
		}

	}


	public static String getFormattedDate(String dateStr) {
		if (StringUtils.isEmpty(dateStr)) {
			return dateStr;
		}
		Date date = getDate(dateStr);
		String formattedDateStr = getDbString(date);

		LOGCMOD.debug("dbstring:"+formattedDateStr);
		return formattedDateStr;
	}


	public static String[] patterns  = {"MM/dd/yyyy","MM-dd-yyyy"};

	public static Date getDate(String dateStr) {
		Date date = null;
		dateStr = StringUtils.trimToEmpty(dateStr);

		try {
			// date = new Date(dateStr);
			date = DateUtils.parseDate(dateStr, patterns);
			 LOGCMOD.debug("date to string:"+date.toString());
		} catch (Exception e) {
			LOGCMOD.warn("exception is:"+e.getMessage());
		}

		return date;
	}




	public static String getDbString(Date date) {
		String dbString = "";
		if (date == null) {
			return "";
		}


		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			dbString = dateFormat.format(date);
		} catch
		(Exception e) {
			LOGCMOD.error("error formatting date:"+e.getMessage());
		}
		return dbString;
	}



	public static String buildCmodJsonResult(String status,String jsonData,int numData,String appData) {
		StringBuffer sb = new StringBuffer("{");
		sb.append("\"resultStatus\":").append("\"").append(status).append("\"");
		sb.append(",");
		sb.append("\"resultNum\":").append("\"").append(numData).append("\"");
		sb.append(",");
		sb.append("\"resultData\":").append(jsonData);
		sb.append(",");
		appData = (StringUtils.isEmpty(appData))?"{}":appData;
		sb.append("\"appData\":").append(appData);
		sb.append("}");

		return sb.toString();
	}

	
	public static String buildCmodJsonErrorMsg(String status,String msg) {
		StringBuffer sb = new StringBuffer("{");
		sb.append("\"resultStatus\":").append("\"").append(status).append("\"");
		sb.append(",");
		sb.append("\"resultMsg\":").append("\"").append(msg).append("\"");
		sb.append("}");

		return sb.toString();
	}
	
	
	public static void printParameters(String msgStr, PortletRequest request) {
		Map<String,String[]> paramMap = request.getParameterMap();
		Set<Entry<String,String[]>> entrySet = paramMap.entrySet();
		StringBuilder sb = new StringBuilder("\nParameters begin for ");
		sb.append(msgStr);
		for (Entry<String,String[]> entry : entrySet) {
			String paramName = entry.getKey();
			String[] paramValueArr = entry.getValue();
			String paramValue = getPrintParameterValue(paramValueArr);
			sb.append("\n    param name:"+paramName);
			sb.append(" value:"+paramValue);
		}

		sb.append("\nParameters end for ").append(msgStr);
		String paramsStr = sb.toString();
		
		LOGCMOD.info(paramsStr);
		// LOGCMOD.info("");
	}

	public static String getPrintParameterValue(String[] paramValueArr) {
		StringBuilder sb = new StringBuilder("");
		if (paramValueArr == null) {
			sb.append("string array null");
		} else {
			int numStrings = paramValueArr.length;
			if (numStrings == 0) {
				sb.append("string array empty");
			} else {
				for (int i=0;i<numStrings;i++) {
					if (i != 0) {
						sb.append(",");
					}
					sb.append(paramValueArr[i]);
				}
			}
		}
		String valueStr = sb.toString();
		return valueStr;
	}
	
	
	/**
	 * Lookup agent type
	 * 
	 * @param uid
	 * @return
	 */
	public static String getUserType(String uid) {
		CmodDatamartDAO cmodDatamartDAO = new CmodDatamartDAO();
		boolean associateF = cmodDatamartDAO.isAssociate(uid);
		LOGCMOD.info("assoicateF is:"+associateF+" for userId:"+uid);
		String agentType = (associateF)?SEARCH_USERTYPE_STAFF: SEARCH_USERTYPE_AGENT;
		return agentType;
	}
	



	
	public static String getCategory(PortletRequest request,String paramName) {
		String paramCategory = CmodUtils.getParamValue(request, paramName);
		paramCategory = (StringUtils.equalsIgnoreCase("ALL", paramCategory))?"":paramCategory;
		return paramCategory;
	}

	
	
	
	public static String getToDate(ResourceRequest request, boolean dateRangeSearchF) {
		String paramToDate = CmodUtils.getParamValue(request, "paramToDate");
		String endDate = CmodUtils.getFormattedDate(paramToDate);
		endDate = (dateRangeSearchF)?endDate:null;
		endDate = (StringUtils.isEmpty(endDate))?SEARCH_ALL_END_DATE:endDate.trim();
		LOGCMOD.info("end date for search:"+endDate);
		
		return endDate;
	}

	public static String getFromDate(ResourceRequest request, boolean dateRangeSearchF) {
		String paramFromDate = CmodUtils.getParamValue(request, "paramFromDate");
		String startDate = CmodUtils.getFormattedDate(paramFromDate);
		startDate = (dateRangeSearchF)?startDate:null;
		startDate = (StringUtils.isEmpty(startDate))?SEARCH_ALL_BEGIN_DATE:startDate.trim();		
		LOGCMOD.info("start date for search:"+startDate);
		
		return startDate;
	}

	public static boolean getDateRangeSearchFlag(String paramHistory) {
		boolean dateRangeSearchF = false;
		if ("daterange".equals(paramHistory)) {
			dateRangeSearchF = true;
		}
		return dateRangeSearchF;
	}

	
	public static String getDocSearchType(String paramSubmitType,
			String paramSearchType) {
		String docSearchType = null;

		if ("DownlineSearch".equals(paramSubmitType)) {
			docSearchType = SEARCH_TYPE_SPECIFC;
		} else {
			if ("H".equals(paramSearchType)) {
				docSearchType = SEARCH_TYPE_HIERARCHY;
			} else if ("P".equals(paramSearchType)){
				docSearchType = SEARCH_TYPE_PERSONAL;
			} else {
				docSearchType = paramSearchType;
			}
		}
		return docSearchType;
	}
	
	
}
