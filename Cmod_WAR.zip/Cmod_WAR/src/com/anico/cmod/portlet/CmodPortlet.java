package com.anico.cmod.portlet;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.util.Hashtable;
import java.util.List;


import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.anico.cmod.CmodErrorHandler;
import com.anico.cmod.CmodException;
import com.anico.cmod.beans.ViewReportsOnStartBean;
import com.anico.cmod.logic.ctd.AgentBean;
import com.anico.cmod.logic.ctd.CTDUtils;
import com.anico.cmod.logic.dao.CmodDatamartDAO;
import com.anico.cmod.services.CmodGetReportsOutputTest;
import com.anico.cmod.services.soapclient.searchapi.CMODSearch;
import com.anico.cmod.services.soapclient.searchapi.CMODSearchService;
import com.anico.cmod.services.soapclient.searchapi.CMOD_SearchPortProxy;
import com.anico.cmod.services.soapclient.searchapi.CmodGetReportsInput;
import com.anico.cmod.services.soapclient.searchapi.CmodGetReportsOutput;
import com.anico.cmod.services.soapclient.searchapi.CmodReports;
import com.anico.cmod.session.CmodSessionBean;
import com.anico.cmod.session.CmodSessionMgr;
import com.anico.dasd.ConfiguredPortlet;
import com.anico.dasd.DASDConfigurationException;
import com.anico.dasd.ldap.AgentInformationFromLDAP;
import com.google.gson.Gson;

import static com.anico.cmod.portlet.CmodPortletConstants.*;
import static com.anico.cmod.portlet.CmodUtils.*;



/**
 * This is the Cmod portlet class.
 * Entry point for basic cmod functionality.
 */
public class CmodPortlet extends ConfiguredPortlet {
	
	
	
	/**
	 * Default CmodPortlet constructor
	 * @throws DASDConfigurationException
	 */
	public CmodPortlet()  throws DASDConfigurationException {
		 super();
	}

	
	/**
	 * @see javax.portlet.Portlet#init()
	 */
	public void init() throws PortletException{
		super.init();
	} 

	/**
	 * Serve up the <code>view</code> mode.
	 * Displays the search page customized to the marketing area
	 * 
	 * @see javax.portlet.GenericPortlet#doView(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		Principal principal = null;
		String uid = null;
		CmodSessionBean cmodSessionBean = null;
		String pageToDisplay = null;
	
		try {	
			LOGCMOD.info("\n\n------------BEGIN CMOD DOVIEW---------------");
			LOGCMOD.info("begin cmod doview cmodbuild-32a");
			
			printParameters("doView",request);

			principal =	request.getUserPrincipal();
			uid = principal.getName();
			LOGCMOD.info("cmod doview uid is:"+uid);
			
			// get session
			cmodSessionBean = CmodSessionMgr.getCmodSessionBean(uid,request);
			
			if (cmodSessionBean == null) {
				CreateAndSetupCmodSession(request, uid);			
			}
				
			// Set the MIME type for the render response
			response.setContentType(request.getResponseContentType());		
			
			
			// handle initial request with params
			String appName = CmodUtils.getParamValue(request, "appName");
			LOGCMOD.info("cmoddoviewparam appName:"+appName);

			String submitType = CmodUtils.getParamValue(request, "submitType");
			LOGCMOD.info("cmoddoviewparam submitType:"+submitType);
			
			boolean viewReportsOnStartF = checkForViewReportsOnStart(appName,submitType);
			LOGCMOD.info("cmoddoviewparam viewReportsOnStartF:"+viewReportsOnStartF);
			request.setAttribute("viewReportsOnStartFlag",viewReportsOnStartF);
			
			ViewReportsOnStartBean viewReportsOnStartBean = getViewReportsOnStartBean(viewReportsOnStartF,request,appName, submitType);	
			request.setAttribute("viewReportsOnStartBean",viewReportsOnStartBean);

					
			pageToDisplay = DEFAULT_INDEX_PAGE;
		} catch (CmodException ce) {
			    LOGCMOD.error("portlet serve resource exception" + ce.getMessage());
			    pageToDisplay = SERVICE_INTERRUPT_PAGE;
			    this.handleCriticalException(ce);
			    LOGCMOD.error("portlet cmod doview exception end");
		} catch (Exception e) {
			    LOGCMOD.error("portlet serve resource exception" + e.getMessage());
		        pageToDisplay = SERVICE_INTERRUPT_PAGE;
			    this.handleCriticalException(e);
			    LOGCMOD.error("portlet cmod doview exception end");
		} finally {
			 if (StringUtils.isEmpty(pageToDisplay)) {
				 LOGCMOD.error("cmod doview finally - pageToDisplay is null");
				 pageToDisplay = SERVICE_INTERRUPT_PAGE;
			 }
			 LOGCMOD.info("pageToDisplay:" + pageToDisplay);

				// render the jsp
				PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(pageToDisplay);
				rd.include(request,response);

				// or write to the response directly
				 // response.getWriter().println("test CmodTest#doView()");



			LOGCMOD.info("\n    END CMOD DOVIEW");
		}				
		
	}


	private ViewReportsOnStartBean getViewReportsOnStartBean(boolean viewReportsOnStartF,
			RenderRequest request, String appName, String submitType) {
		ViewReportsOnStartBean viewReportsOnStartBean = new ViewReportsOnStartBean(appName,submitType);
		if (!viewReportsOnStartF) {
			return viewReportsOnStartBean;
		}
		
		if (StringUtils.isNotEmpty(appName)) {
			viewReportsOnStartBean.setAppCallF(true);
		} else {
			viewReportsOnStartBean.setAppCallF(false);
		}

		String category = getCategory(request,"category");	
		if (StringUtils.isEmpty(category)) {
			category = SEARCH_CATEGORY_ALL;
		}
		LOGCMOD.info("cmoddoviewparam category:"+category);
		viewReportsOnStartBean.setCategory(category);
		
		String policynum = CmodUtils.getParamValue(request, "policynum");
		LOGCMOD.info("cmoddoviewparam policynum:"+policynum);
		viewReportsOnStartBean.setPolicynum(policynum);
		
		String reportName = CmodUtils.getParamValue(request, "reportName");
		LOGCMOD.info("cmoddoviewparam reportName:"+reportName);
		viewReportsOnStartBean.setReportName(reportName);
		
		return viewReportsOnStartBean;
	}


	private boolean checkForViewReportsOnStart(String appName, String submitType) {
		boolean viewReportsOnStartF = false;
		if (StringUtils.isNotEmpty(appName)) {
			viewReportsOnStartF = true;
		}
		
		if (StringUtils.isNotEmpty(submitType)) {
			viewReportsOnStartF = true;
		}
		return viewReportsOnStartF;
	}

	
	private void CreateAndSetupCmodSession(RenderRequest request, String uid) {
		CmodSessionBean cmodSessionBean;
		cmodSessionBean = CmodSessionMgr.createCmodSessionBean(uid, request);
		
		AgentInformationFromLDAP result = null;
		String marketingArea = null;
		String userName = DEFAULT_USER_NAME;

		String ssn = null;
		try {
			result = AgentInformationFromLDAP.getBasicInfoFromLdap(uid);
			marketingArea = (String)result.get(LDAP_ATTRIBUTE_MARKETING_AREA);
			LOGCMOD.info("cmod marketingArea is:"+marketingArea);
			marketingArea = StringUtils.trimToEmpty(marketingArea);
			marketingArea = marketingArea.toUpperCase();
			
			userName = (String)result.get(LDAP_ATTRIBUTE_USER_NAME);
			LOGCMOD.info("cmod user name is:"+userName);
			
			ssn = (String)result.get(LDAP_ATTRIBUTE_SSN);								
			LOGCMOD.info("getting attribute");
			
			CmodDatamartDAO cmodDatamartDAO = new CmodDatamartDAO();
			boolean managerFlag = cmodDatamartDAO.isManager(ssn);
			LOGCMOD.info("isManager is:"+managerFlag+" for uid:"+uid);
			
			String userType = getUserType(uid);
			LOGCMOD.info("userType is:"+userType+" for uid:"+uid);
			
			// set attributes
			cmodSessionBean.setUid(uid);
			cmodSessionBean.setMarketingArea(marketingArea);
			cmodSessionBean.setUserName(userName);
			cmodSessionBean.setSsn(ssn);
			cmodSessionBean.setManagerFlag(managerFlag);
			cmodSessionBean.setUserType(userType);
			
			
		} catch (Exception e) {
			LOGCMOD.error("main error in doview"+e.getMessage());
		} finally {

		}
	}




	/**
	 * Serve up the <code>edit</code> mode.
	 *
	 * @see javax.portlet.GenericPortlet#doEdit(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	public void doEdit(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// auto-generated method stub
	}

	/**
	 * Serve up the <code>help</code> mode.
	 *
	 * @see javax.portlet.GenericPortlet#doHelp(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	protected void doHelp(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// auto-generated method stub
	}

	/**
	 * Process an action request.
	 *
	 * @see javax.portlet.Portlet#processAction(javax.portlet.ActionRequest, javax.portlet.ActionResponse)
	 */
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		// auto-generated method stub
	}


	/** 
	 * Handles ajax type request, including report search, downline search and report lookup.
	 * 
	 * @see javax.portlet.GenericPortlet#serveResource(javax.portlet.ResourceRequest, javax.portlet.ResourceResponse)
	 */
	public void serveResource(ResourceRequest request, ResourceResponse response)
			throws PortletException {
		InputStream  inStream = null;
		OutputStream outStream = null;
		String jsonStr = null;
		String resourceID = null;
		Principal principal = null;
		String uid = null;
		
					
		try {
			
			LOGCMOD.info("\n\n------------BEGIN CMOD SERVE_RESOURCE---------------");
			LOGCMOD.info("begin cmod serveResource cmodbuild-32b");
			
			resourceID = request.getResourceID();
			principal =	request.getUserPrincipal();
			uid = principal.getName();		
			String serveResourceMsgId = "resourceID:"+resourceID+" for uid:"+uid; 
			LOGCMOD.info(serveResourceMsgId);				
			printParameters("serveResource for "+serveResourceMsgId ,request);
			
			// verify session
			CmodSessionBean cmodSessionBean = CmodSessionMgr.getCmodSessionBean(uid,request);
						

			if (cmodSessionBean == null) {
                LOGCMOD.info("\n    session timed out, no cmod sessionBean");
               
                // this message will also be sent out by devl, prod servers
				PrintWriter pw = response.getWriter();
				pw.write(SERVICE_SESSION_TIMEOUT_INDICATOR);

				LOGCMOD.info("\n  returning session timed out indicator");
				return;
			}			
			
						
	        CMODSearchService cmodSvc = new CMODSearchService();
			CMODSearch cmodSearchPort = cmodSvc.getCMODSearchPort();

			// GET REPORTS LIST - SEARCH
			if (resourceID.equals(RESOURCE_ID_GET_REPORTS_LIST)) {
				getReportListBySearch(uid,request,response, cmodSearchPort,cmodSessionBean);

			}
			
			// GET PDF DATA
			else if ((resourceID.equals(RESOURCE_ID_DOWNLOAD_REPORT))
					|| (resourceID.equals(RESOURCE_ID_SHOW_REPORT)) ) {
				
				outStream = getPdfFromUrl(uid,request, response, resourceID,cmodSessionBean);
			}
			
			// GET DOWNLINE LIST
			else if (resourceID.equals(RESOURCE_ID_GET_DOWNLINE)){
				LOGCMOD.info("begin downline process");
				getDownline(uid,request,response);
				LOGCMOD.info("end downline process");
			}			
			
			// GET REPORTS LIST TEST - SEARCH
			else if (resourceID.equals(RESOURCE_ID_GET_REPORTS_LIST_TEST)){
				getReportsListTest(response);
			}			

			// GET PDF TEST - gets hardcode pdf binary from a file
			else if ((resourceID.equals(RESOURCE_ID_DOWNLOAD_REPORT_TEST))
					|| (resourceID.equals(RESOURCE_ID_SHOW_REPORT_TEST)) ) {
				inStream = getPdfFromFileTest(request, response, resourceID);
		        outStream = response.getPortletOutputStream();
				int b = 0;
				while ( (b = inStream.read()) != -1) {
					outStream.write(b);
				}
			}

			// UNKNOWN REQUEST
			else {
				LOGCMOD.error("unknown resource id:"+resourceID);
			}

		} catch (Exception e) {
			LOGCMOD.error("exception in cmod serve resource:"+e.getMessage());
			
		    this.handleCriticalException(e);
		    LOGCMOD.error("cmod portlet serve resource exception end");
			
			jsonStr = CmodUtils.buildCmodJsonErrorMsg(STATUS_ERROR,MSG_ERROR);
			try {
				response.getWriter().println(jsonStr);	
			} catch (Exception ne) {
				LOGCMOD.error("nested exception in cmod serve resource:"+ne.getMessage());
			}			
			
		} finally {
			LOGCMOD.debug("cmod serve resource finally");
			if (inStream != null) {
				try {
					inStream.close();
				} catch (Exception ioe) {
					LOGCMOD.error("inputstream close error:"+ioe.getMessage());
				}
			}

			if (outStream != null) {
				try {
					outStream.close();
				} catch (Exception ioe) {
					LOGCMOD.error("outstream close error:"+ioe.getMessage());
				}
			}

		}

		LOGCMOD.info("end cmod serveResource");
	}

	
	
	/**
	 * Get list of downline agents for logged in user.
	 * 
	 * @param uid
	 * @param request
	 * @param response
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	private void getDownline(String uid,ResourceRequest request,ResourceResponse response)
			throws UnsupportedEncodingException, IOException {
		String jsonStr;
		LOGCMOD.info("running search cmod lookup");
		response.setContentType("application/json");
		
		// get downline search codes
		AgentInformationFromLDAP result = null;
		String marketingArea = null;
		Hashtable<String,String> codes = null;
		String ssn = null;		
		try {
			result = AgentInformationFromLDAP.getBasicInfoFromLdap(uid);
			marketingArea = (String)result.get("MARKETINGAREA");
			LOGCMOD.info("marketing area is:"+marketingArea);
			ssn = (String)result.get("ssn");
			codes = CTDUtils.getMultiCodes(result);

		} catch (Exception e) {
			LOGCMOD.error("main error getting email addr, msg:"+e.getMessage());
			throw new CmodException("error in agent downline lookup"+e.getMessage());
		} finally {

		}

		// downline search
		List<AgentBean> downline = null;
		int numDownline = 0;
		try {
			CmodDatamartDAO cmodDatamartDAO = new CmodDatamartDAO();
			downline = cmodDatamartDAO.getDownline(ssn,codes);
			numDownline = downline.size();
			LOGCMOD.info("num downline is:"+numDownline+" for uid:"+uid);

		} catch (Exception e) {
			LOGCMOD.error("main error getting email addr, msg:"+e.getMessage());
			throw new CmodException("error in db downline lookup"+e.getMessage());
		} finally {

		}


		Gson gson = new Gson();
		jsonStr = gson.toJson(downline);

		String resultStatus = STATUS_OK;
		if (numDownline == 0) {
		   resultStatus = STATUS_NO_DOWNLINE_FOUND;
		}

		jsonStr = CmodUtils.buildCmodJsonResult(resultStatus,jsonStr,numDownline,null);

		LOGCMOD.debug("searchcmod result jsonstr:"+jsonStr);

		// jsonStr = "{\"testname1\":\"testvalue1\"}";

		response.getWriter().println(jsonStr);
	}
	
	

	/**
	 * Get static pdf file for display test.
	 * 
	 * @param request
	 * @param response
	 * @param resourceID
	 * @return
	 * @throws FileNotFoundException
	 */
	private InputStream getPdfFromFileTest(ResourceRequest request,
			ResourceResponse response, String resourceID)
			throws FileNotFoundException {
		InputStream inStream;

		LOGCMOD.info("in server dowload file");
		response.setContentType(PDF_MIME_CONTENT_TYPE_DEFINITION);

		String paramRptName = request.getParameter("paramRptName");
		LOGCMOD.info("server side paramRptName:"+paramRptName);

		String paramRptHnd = request.getParameter("paramRptHnd");
		LOGCMOD.info("server side paramRptHnd:"+paramRptHnd);

		if (resourceID.equals(RESOURCE_ID_DOWNLOAD_REPORT_TEST)) {
			response.setProperty(CONTENT_DISPOSITION, CONTENT_TYPE + FILENAME
					+ paramRptName + PDF_EXTENSION);
		}

		// TEST CODE
		String relativePath = getPortletContext().getRealPath("");
		LOGCMOD.info("relativePath = " + relativePath);
		// relativePath = C:\RAD_FDRS\rad85_wps_ws\CmodTest\WebContent\

		String fullFileName = relativePath + "pdfs\\ADMREQS.pdf";


		inStream = new FileInputStream(fullFileName);

		return inStream;
	}

	
	/**
	 * Get test list of reports to check list view.
	 *  
	 * @param response
	 * @throws IOException
	 */
	private void getReportsListTest(ResourceResponse response)
			throws IOException {
		String jsonStr;
		CmodGetReportsOutput searchCMODOutput = CmodGetReportsOutputTest.getCmodSearchOuputSample();
		LOGCMOD.debug("test obj:"+searchCMODOutput);

		Gson gson = new Gson();
		jsonStr = gson.toJson(searchCMODOutput);
		LOGCMOD.debug("searchcmod result jsonstr:"+jsonStr);
		response.getWriter().println(jsonStr);
	}



	/**
	 * Reports Search
	 * returns list of reports
	 * 
	 * @param request
	 * @param response
	 * @param cmodSearchPort
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	private void getReportListBySearch(String uid,ResourceRequest request,
			ResourceResponse response, CMODSearch cmodSearchPort,CmodSessionBean sessionBean)
			throws UnsupportedEncodingException, IOException {
		String jsonStr;
		LOGCMOD.info("cmod getReportsListBySearch begin");
		response.setContentType("application/json");

		String paramSubmitType = CmodUtils.getParamValue(request, "paramSubmitType");
		String paramCategory = getCategory(request,"paramCategory");
		String paramReportName = CmodUtils.getParamValue(request, "paramReportName");
		String paramPolicyNum = CmodUtils.getParamValue(request, "paramPolicyNum");
		String paramUserSearchType = CmodUtils.getParamValue(request, "paramUserSearchType");
		String paramDownlineAgent = CmodUtils.getParamValue(request, "paramDownlineAgent");
		String paramHistory = CmodUtils.getParamValue(request, "paramHistory");
		boolean dateRangeSearchF = getDateRangeSearchFlag(paramHistory);
		String startDate = getFromDate(request, dateRangeSearchF);
		String endDate = getToDate(request, dateRangeSearchF);
		

		// set search values 
		CmodGetReportsInput searchCmodInput = new CmodGetReportsInput();
		searchCmodInput.setUserID(uid);
		searchCmodInput.setFolderID(CMOD_FOLDER_ID);
		searchCmodInput.setNoOfItems(SEARCH_MAX_RETURN_SIZE);
		String userType = sessionBean.getUserType();
		searchCmodInput.setUserType(userType);
		searchCmodInput.setStartDate(startDate);
		searchCmodInput.setEndDate(endDate);
		
		Boolean managerF = sessionBean.getManagerFlag();
		LOGCMOD.info("getReportsListBySearch managerF:"+managerF);

		
		if (SUBMIT_TYPE_QUICK_REPORT_NAME.equals(paramSubmitType)) {
			if (managerF) {
				searchCmodInput.setSearchType(SEARCH_TYPE_COMBINED);	
				LOGCMOD.info("getReportsListBySearch quick report name search combined");
			} else {
				searchCmodInput.setSearchType(SEARCH_TYPE_PERSONAL);
				LOGCMOD.info("getReportsListBySearch quick report name search personal");
			}			
			searchCmodInput.setReportName(paramReportName);
		} else if (SUBMIT_TYPE_QUICK_CATEGORY.equals(paramSubmitType)) {
			searchCmodInput.setSearchCatogoryID(paramCategory);
			if (managerF) {
				searchCmodInput.setSearchType(SEARCH_TYPE_COMBINED);	
				LOGCMOD.info("getReportsListBySearch quick category search combined");
			} else {
				searchCmodInput.setSearchType(SEARCH_TYPE_PERSONAL);
				LOGCMOD.info("getReportsListBySearch quick category search personal");
			}			
		}  else if (SUBMIT_TYPE_FORM.equals(paramSubmitType)) {
			
			if (SEARCH_USER_SEARCH_TYPE_HIERARCHY.equals(paramUserSearchType)) {
				searchCmodInput.setSearchType(SEARCH_TYPE_COMBINED);			
				LOGCMOD.info("getReportsListBySearch form search combined");
			} else {
				searchCmodInput.setSearchType(SEARCH_TYPE_PERSONAL);
				LOGCMOD.info("getReportsListBySearch form search combined");
			}

			searchCmodInput.setSearchCatogoryID(paramCategory);
			searchCmodInput.setPolicyNumber(paramPolicyNum);
		} else if (SUBMIT_TYPE_DOWNLINE.equals(paramSubmitType)) {
			searchCmodInput.setSearchType(SEARCH_TYPE_SPECIFC);
			LOGCMOD.info("getReportsListBySearch downline search specific");
			searchCmodInput.setSearchCatogoryID(paramCategory);
			searchCmodInput.setPolicyNumber(paramPolicyNum);
			if (StringUtils.isEmpty(paramDownlineAgent)){
				paramDownlineAgent = uid;
			}
			searchCmodInput.setSearchAgent(paramDownlineAgent);
		} else {
			LOGCMOD.error("unknown submit type");
			LOGCMOD.info("getReportsListBySearch unknown - search none");
			paramSubmitType = SUBMIT_TYPE_NONE;
		}


		// make call to get list of reports
		String serviceEndpointUrl = CmodPortletConfig.getCmodSoapServiceEndpointUrl();
		CmodGetReportsOutput searchCMODOutput = null;
		
		if (!SUBMIT_TYPE_NONE.equals(paramSubmitType)) {
			// searchCMODOutput = cmodSearchPort.getUniqueReportsList(searchCmodInput);
			CMOD_SearchPortProxy cmodSearchPortProxy = new CMOD_SearchPortProxy();			
			cmodSearchPortProxy._getDescriptor().setEndpoint(serviceEndpointUrl);
			LOGCMOD.info("CmodSoapService - Calling getUniqueReportsList at:"+serviceEndpointUrl);
			searchCMODOutput = cmodSearchPortProxy.getUniqueReportsList(searchCmodInput);
			LOGCMOD.info("CmodSoapService - Call complete for getUniqueReportsList at:"+serviceEndpointUrl);
			if (searchCMODOutput == null) {
				LOGCMOD.error("CmodSoapService - searchCmodOutput was null");
			} else {
				LOGCMOD.error("CmodSoapService - searchCmodOutput is not null");
			}
			
			String rtnCode = searchCMODOutput.getReturnCode();
			String rtnMessage = searchCMODOutput.getReturnMessage();
			LOGCMOD.info("CmodSoapService - ReturnCode:"+rtnCode+" ReturnMessage:"+rtnMessage);
			
		}
		LOGCMOD.info("result obj:"+searchCMODOutput);
		
		// process results
		jsonStr = processSearchResults(searchCmodInput,searchCMODOutput);
		LOGCMOD.debug("searchcmod result jsonstr:"+jsonStr);

		response.getWriter().println(jsonStr);
	}

	



	/**
	 * process and build search result in json.
	 * 
	 * @param searchCmodInput
	 * @param searchCMODOutput
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	private String processSearchResults(CmodGetReportsInput searchCmodInput,CmodGetReportsOutput searchCMODOutput)
			throws UnsupportedEncodingException {
		String resultJsonStr;
		List<CmodReports> reportsList = searchCMODOutput.getReportsList();
		int numReports = (reportsList == null)? 0 : reportsList.size();

		Gson gson = new Gson();
		resultJsonStr = gson.toJson(searchCMODOutput);

		String resultStatus = STATUS_OK;
		if (numReports == 0) {
		   resultStatus = STATUS_NO_REPORTS_FOUND;
		}

		// app data for criteria
		StringBuilder sb = new StringBuilder("{");
		sb.append("\"searchType\":");
		sb.append("\"").append(searchCmodInput.getSearchType()).append("\"");
		sb.append("}");
		String appData = sb.toString();

		resultJsonStr = CmodUtils.buildCmodJsonResult(resultStatus,resultJsonStr,numReports,appData);
		return resultJsonStr;
	}

	
	
	/**
	 * Process request to get report pdf.
	 * 
	 * @param uid
	 * @param request
	 * @param response
	 * @param resourceID
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	private OutputStream getPdfFromUrl(String uid,ResourceRequest request,
			ResourceResponse response, String resourceID,CmodSessionBean sessionBean)
			throws UnsupportedEncodingException, IOException {

		OutputStream outStream;
		LOGCMOD.info("Begin getPdfFromUrl");
		response.setContentType(PDF_MIME_CONTENT_TYPE_DEFINITION);

		// String paramUserId = CmodUtils.getParamValue(request, "paramUserId");
		String paramSubmitType = CmodUtils.getParamValue(request, "paramSubmitType");
		String paramDownlineAgent = CmodUtils.getParamValue(request, "paramDownlineAgent");
		String paramRptCategory = CmodUtils.getParamValue(request, "paramRptCategory");
		String paramRptPolicyNum = CmodUtils.getParamValue(request, "paramRptPolicyNum");
		String paramRptName = CmodUtils.getParamValue(request, "paramRptName");
		String paramRptAppName = CmodUtils.getParamValue(request, "paramRptAppName");
		String paramRptDate = CmodUtils.getParamValue(request, "paramRptDate");
		String paramSearchType = CmodUtils.getParamValue(request, "paramSearchType");
		String docSearchType = getDocSearchType(paramSubmitType,paramSearchType);
		String userType = sessionBean.getUserType();

		if (resourceID.equals(RESOURCE_ID_DOWNLOAD_REPORT)) {
			response.setProperty(CONTENT_DISPOSITION, CONTENT_TYPE + FILENAME
					+ paramRptName + PDF_EXTENSION);
		}

		// tbdv - update pdf call - downloadreport - config
		// String pdfUrl = "http://svtw-cmod1.dnanico1.aniconet.com:9080/CMODServiceV4/GetCOMReports";
		String pdfUrl = CmodPortletConfig.getPdfServiceUrl();
		StringBuilder sb = new StringBuilder(pdfUrl);
        
		// fixed values
        sb.append("?folder=").append(getUrlEncodedValue(CMOD_FOLDER_ID));
		sb.append("&userID=").append(getUrlEncodedValue(uid));
		sb.append("&userType=").append(getUrlEncodedValue(userType));

        // report specific values
		sb.append("&reportName=").append(getUrlEncodedValue(paramRptName));
		sb.append("&reportDate=").append(getUrlEncodedValue(paramRptDate));
		sb.append("&searchCatogoryID=").append(getUrlEncodedValue(paramRptCategory));
		sb.append("&appName=").append(getUrlEncodedValue(paramRptAppName));
		
		if(StringUtils.isNotEmpty(paramRptPolicyNum)) {
			sb.append("&policyNumber=").append(getUrlEncodedValue(paramRptPolicyNum));
			LOGCMOD.info("cmod policynum sending:"+paramRptPolicyNum);
		} else {
			LOGCMOD.info("cmod policynum not sending since it is empty");
		}
		
        // search value
        sb.append("&searchType=").append(getUrlEncodedValue(docSearchType));

        // for specific agent only
		if ("DownlineSearch".equals(paramSubmitType)) {
			sb.append("&searchAgent=").append(getUrlEncodedValue(paramDownlineAgent));
		}

		String requestUrl = sb.toString();
		LOGCMOD.info("");
		LOGCMOD.info("Request Url is:"+requestUrl);
		LOGCMOD.info("cmod backend service being called...");
		// call back end pdf service
        byte[] byteArr = callAndGetPdfData(requestUrl);
		int byteArrLen = (byteArr == null)?0:byteArr.length;
		LOGCMOD.info("Received return number of bytes:"+byteArrLen);

		// send pdf data in response
		LOGCMOD.info("Begin write to respone:"+byteArrLen);
		outStream = response.getPortletOutputStream();
		writePdfDataToRespone(outStream, byteArr, byteArrLen);
		LOGCMOD.info("Written to respone:"+byteArrLen);
		
		
		LOGCMOD.info("End getPdfFromUrl");
		
		return outStream;
	}

	/**
	 * Helper method to write data to response.
	 * @param outStream
	 * @param byteArr
	 * @param byteArrLen
	 * @throws IOException
	 */
	private void writePdfDataToRespone(OutputStream outStream, byte[] byteArr,
			int byteArrLen) throws IOException {
		int b = 0;
		for (int i=0;i<byteArrLen;i++) {
			b = byteArr[i];
			outStream.write(b);
		}
	}

	
	/**
	 * Make http call to get pdf data.
	 * 
	 * @param requestUrl
	 * @return
	 */
	private byte[] callAndGetPdfData(String requestUrl) {
		HttpClient httpclient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(requestUrl);

        ResponseHandler<byte[]> handler = new ResponseHandler<byte[]>() {
            public byte[] handleResponse(
                HttpResponse response) throws ClientProtocolException, IOException {
                LOGCMOD.info("getpdf in response handler");
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                	LOGCMOD.info("getpdf entity is not null");
                    return EntityUtils.toByteArray(entity);
                } else {
                	LOGCMOD.info("getpdf entity in response is null");
                    return null;
                }
            }
        };

        byte[] byteArr = null;

        try {
            byteArr = httpclient.execute(httpPost, handler);
        } catch (Exception e) {
            LOGCMOD.error("getpdf exception:"+e.getMessage());
        }
		return byteArr;
	}

	/**
	 *
	 * @return
	 */
	protected String getErrorHandlerClassName() {

		return CmodErrorHandler.class.getName();

	}
	

}
