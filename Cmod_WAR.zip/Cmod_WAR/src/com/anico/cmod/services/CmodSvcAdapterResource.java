/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*/

package com.anico.cmod.services;

import java.util.List;
import java.util.logging.Logger;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.anico.cmod.services.soapclient.searchapi.CMODSearch;
import com.anico.cmod.services.soapclient.searchapi.CMODSearchService;
import com.anico.cmod.services.soapclient.searchapi.CmodGetReportsInput;
import com.anico.cmod.services.soapclient.searchapi.CmodGetReportsOutput;
import com.google.gson.Gson;


@Path("/cmodService")
public class CmodSvcAdapterResource {
	/*
	 * For more info on JAX-RS see https://jsr311.java.net/nonav/releases/1.1/index.html
	 */
		
	//Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(CmodSvcAdapterResource.class.getName());

    //Define the server api to be able to perform server operations
    // WLServerAPI api = WLServerAPIProvider.getWLServerAPI();

	/* Path for method: "<server address>/CmodProj/adapters/CmodSvcAdapter/users" */
	@GET
	@Produces("application/xml")
	public String hello(){
		//log message to server log
        logger.info("Logging info message...");
        
		return "<title>Hello from the Java REST adapter</title><body>Hello from the Java REST adapter</body>";
	}
	

    
	/* Path for method: "<server address>/CmodProj/adapters/CmodSvc/users" */
	@GET
	@Path("/test")
	@Produces("application/json")
	public String testCmodSvc(){
		//log message to server log
        logger.info("Logging info message...");
        
        String jsonStr = "{\"result\":\"cmod test str2\"}";
        
		return jsonStr;
	}

	
	@GET
	@Path("/searchCmod")
	@Produces("application/json")	
	public String searchCmod(@QueryParam("userid") String userId){ 
		//log message to server log
        logger.info("in searchCmod"); 
        logger.info("userid in searchcmod is:"+userId);
        
        String jsonStr = null; 
        
		CMODSearchService cmodSvc = new CMODSearchService();
		CMODSearch cmodSearchPort = cmodSvc.getCMODSearchPort();
				
		CmodGetReportsInput searchCmodInput = new CmodGetReportsInput();		
		searchCmodInput.setUserID(userId);
		
		CmodGetReportsOutput searchCMODOutput = cmodSearchPort.getReportsList(searchCmodInput);
		
		logger.info("result obj:"+searchCMODOutput);
				
		Gson gson = new Gson();
		jsonStr = gson.toJson(searchCMODOutput);
		logger.info("searchcmod result jsonstr:"+jsonStr);
        
		return jsonStr;
	}	
	
	
	
	
	

/*	 tbd 
	@GET
	@Path("/getCmodFolders")
	@Produces("application/json")
	public String getCmodFolders(){
		//log message to server log
        logger.info("Logging info message getCmodFolders");
        
        String jsonStr = "{val1:foo, val2:abc}";
        
		CMODSearchService cmodSvc = new CMODSearchService();
		CMODSearch cmodSearchPort = cmodSvc.getCMODSearchPort();
		
		// SearchCMODInput searchCMODInput = new SearchCMODInput();
		// searchCMODInput.setSpecifiedAgent("A00001");
		
		List<String> cmodFolderList = cmodSearchPort.listCMODFolders();
		
		int len = cmodFolderList.size();
		logger.info("result list len:"+len);
		
		for (String s : cmodFolderList) {
			logger.info("list item value is:"+s);
		}
		
		Gson gson = new Gson();
		jsonStr = gson.toJson(cmodFolderList);
		
        
		return jsonStr;
	}	
*/	
	
	
	

	
	
		
	/* Path for method: "<server address>/CmodProj/adapters/CmodSvcAdapter/users/{username}" */
	@GET
	@Path("/{username}")
	public String helloUser(@PathParam("username") String name){
		return "Hello " + name;
	}
	
	/* Path for method: "<server address>/CmodProj/adapters/CmodSvcAdapter/users/helloUserQuery?name=value" */
	@GET
	@Path("/helloUserQuery")
	public String helloUserQuery(@QueryParam("username") String name){
		return "Hello " + name;
	}
	
	
	/* Path for method: "<server address>/CmodProj/adapters/CmodSvcAdapter/users/{first}/{middle}/{last}?age=value" */
	@POST
	@Path("/{first}/{middle}/{last}")
	public String enterInfo(@PathParam("first") String first, @PathParam("middle") String middle, @PathParam("last") String last,
			@QueryParam("age") int age, @FormParam("height") String height, @HeaderParam("Date") String date){
		return first +" "+ middle + " " + last + "\n" +
				"Age: " + age + "\n" +
				"Height: " + height + "\n" +
				"Date: " + date;
	}
	
	/* Path for method: "<server address>/CmodProj/adapters/CmodSvcAdapter/users/newUsers" */
	@PUT
	@Path("/newUsers")
	public String newUsers(@FormParam("username") List<String> users){
		if(users!=null && users.size() != 0){
			String usersTemp = "";
			int index = 0;
			for (String user : users) {
				usersTemp += " " +user;
				if(index < users.size() - 1 && users.size() != 2) usersTemp += ",";
				if(++index == users.size() -1 && users.size() != 1) usersTemp += " and";
			}
			return "Hello" + usersTemp;
		}
		
		return "Hello";
	}
}
