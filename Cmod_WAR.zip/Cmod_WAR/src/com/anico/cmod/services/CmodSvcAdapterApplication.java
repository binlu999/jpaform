/*
 *    Licensed Materials - Property of IBM
 *    5725-I43 (C) Copyright IBM Corp. 2015. All Rights Reserved.
 *    US Government Users Restricted Rights - Use, duplication or
 *    disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*/

package com.anico.cmod.services;

import java.util.HashSet;
import java.util.Set;


import javax.ws.rs.core.Application;

public class CmodSvcAdapterApplication extends Application {
	
	
    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<Class<?>>();

        // Resources
        classes.add( com.anico.cmod.services.CmodSvcAdapterResource.class );

        // Providers

        return classes;
    }

}
