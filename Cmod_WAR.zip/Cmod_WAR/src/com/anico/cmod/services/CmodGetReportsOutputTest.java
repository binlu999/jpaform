package com.anico.cmod.services;

import java.util.List;

import com.anico.cmod.services.soapclient.searchapi.CmodGetReportsOutput;
import com.anico.cmod.services.soapclient.searchapi.CmodReports;

public class CmodGetReportsOutputTest  {
	
	
	
	public static CmodGetReportsOutput getCmodSearchOuputSample() {
		CmodGetReportsOutput obj = new CmodGetReportsOutput();
		
		obj.setFolderName("testfdr");
		obj.setReturnCode("0");
		obj.setReturnMessage("success");
		
		List<CmodReports> reportsList = obj.getReportsList();
		CmodReports rpt = null;
		
		rpt = new CmodReports();
		rpt.setReportName("reportName1");
		rpt.setReportDate("2015-08-01");
		reportsList.add(rpt);

		rpt = new CmodReports();
		rpt.setReportName("reportName2");
		rpt.setReportDate("2015-08-02");
		reportsList.add(rpt);

		
		rpt = new CmodReports();
		rpt.setReportName("reportName3");
		rpt.setReportDate("2015-08-03");
		reportsList.add(rpt);
		
		
		return obj;
	}

}
