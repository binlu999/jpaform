package com.anico.cmod;

import com.anico.dasd.ConfiguredErrorHandler;
import com.anico.dasd.DASDConfigurationException;
import com.anico.dasd.ServletConfigReader;



public class CmodErrorHandler extends ConfiguredErrorHandler {

	public CmodErrorHandler() throws DASDConfigurationException {
		super(new ServletConfigReader(Boolean.FALSE.booleanValue())
				.readAndGetConfig(CmodErrorHandler.class.getName()));
	} 

}


