
/* JavaScript content from js/app.js in folder common */
/**
 * 
 */

 // alert('appjs 2 from content');


var cmodNgApp = angular.module('cmodNgApp', [
  'ngRoute',
  'ui.bootstrap',
  'cmodControllerMod',
  'ui.grid',
  'ui.grid.pagination',
  'ui.grid.cellNav',
  'ngMessages'
]);


var cmodControllerMod = angular.module('cmodControllerMod', ['cmodSvcMod']);

var cmodSvcMod = angular.module("cmodSvcMod",[]);



// alert('test1b'); 

// alert("cmodBaseUrl app:"+cmodBaseUrl);

cmodNgApp.config(['$routeProvider',
                    function($routeProvider) {
                      $routeProvider.
                        when('/search', {
                          templateUrl: cmodBaseUrl+ '/views/searchView.html',
                          controller: 'cmodSearchCtrl'
                        }).
                        when('/testList', {
                          templateUrl: cmodBaseUrl+ '/views/testListView.html',
                          controller: 'cmodTestListCtrl'
                        }).
                        when('/list', {
                            templateUrl: cmodBaseUrl+ '/views/listView.html',
                            controller: 'cmodListCtrl'
                          }).                        
                        when('/rpt', {
                            templateUrl: cmodBaseUrl+ '/views/rptView.html',
                            controller: 'rptCtrl'
                          }).
                          when('/downline', {
                              templateUrl: cmodBaseUrl+ '/views/downlineView.html',
                              controller: 'downlineCtrl'
                            }).                                                  
                        when('/tabs', {
                            templateUrl: cmodBaseUrl+ '/views/tabsView.html',
                            controller: 'tabsCtrl' 
                          }).
                          when('/grid', {
                              templateUrl: cmodBaseUrl+ '/views/gridView.html',
                              controller: 'gridCtrl' 
                            }).                        
                          when('/date', {
                                templateUrl: cmodBaseUrl+ '/views/dateView.html',
                                controller: 'dateCtrl' 
                              }).      
                              when('/error', {
                                  templateUrl: cmodBaseUrl+ '/views/errorView.html',
                                  controller: 'cmodErrorCtrl'
                                }).                               
                        otherwise({
                          redirectTo: '/search'
                        });
                    }]);


// alert('test1ca');
