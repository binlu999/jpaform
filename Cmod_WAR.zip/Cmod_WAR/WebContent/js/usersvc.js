
/* JavaScript content from js/usersvc.js in folder common */
/**
 * 
 */

 
cmodSvcMod.factory("userSvc", function() {
	var userObj = {};
	
	
	// user search defaults
	  userObj.search = {};
	  userObj.search.submitType = '';
	  userObj.search.category = 'ALL';
	  userObj.search.history = 'available'; // 'daterange';	  	  
	  userObj.search.fromDate = ''; // getDefaultFromDate();
	  userObj.search.toDate = '';   //getDefaultToDate();
	  	  
	  userObj.search.policyNum = '';
	  userObj.search.reportName = '';
	  userObj.search.userSearchType = 'personal';
	
	// user results
	  userObj.searchResultsObj = {
			  	resultStatus:'',
			  	
			 // for fields used in data selectedRptObj below
			  	resultData:{}, // has array field, reportsList:[]     
			  	resultNum:0,
			  	appData:{searchType:''}};
	  
	  	  
	// login 
	  userObj.userInfo = {};
	  userObj.userInfo.userId =  uid; // 'A04602';
	  userObj.userInfo.userName = userName; // first and last
	  userObj.userInfo.marketingArea = marketingArea;  // MLM
	  userObj.userInfo.pwd = '';
	  userObj.userInfo.managerFlag = managerFlag;  // true/false
	  userObj.userInfo.quickBtnsView = quickBtnsView; // url for quick search buttons mktArea view
	  
	  
	// user selected report
	  userObj.selectedRptObj = {};
	  userObj.selectedRptObj.rptName = ''; 
	  userObj.selectedRptObj.rptHnd = '';   // not used in new rpt lookup
      userObj.selectedRptObj.rptAppGroupName = ''; // not used in new rpt lookup
      userObj.selectedRptObj.rptApplicationName = ''; // not used in new rpt lookup
      userObj.selectedRptObj.rptDocType = '';
      userObj.selectedRptObj.rptCategory = '';
      userObj.selectedRptObj.rptAppName = '';
      userObj.selectedRptObj.rptPolicyNum = '';
      
	        
      // downline results
      userObj.downlineResultsObj = {resultStatus:'',resultData:{},resultNum:0};	  
      userObj.downlineSelectedObj = {downlineSelectedAgent:''};
      	
	
      // downline selected Agent
      userObj.selectedAgentContainer = {};
      userObj.selectedAgentContainer.selectedAgentObj = {logonId:'',firstName:'',lastName:'',email:''};
      
      
      
	return userObj;
});