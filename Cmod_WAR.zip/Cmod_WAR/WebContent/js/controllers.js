
/* JavaScript content from js/controllers.js in folder common */


// alert("loading controller js 1");

// var cmodControllers = angular.module('cmodControllers', ['cmodSvcMod']);



var fooGlobal = "fooglobaval";


// var userObj = {};
// userObj.search = {};

cmodControllerMod.controller('cmodSearchCtrl', function ($scope,$rootScope,$http,$location,appSvc,userSvc,$filter) {
		// alert("in cmod search ctrl");
    	$scope.viewName = "Cmod Search1 View";
    	$scope.userInfo = userSvc.userInfo;

    	// var myval = $filter('date')(new Date('Fri Nov 06 2015 00:00:00 GMT-0600 (Central Standard Time)'),'yyyy-MM-dd');
   
    	$scope.categories = appSvc.categories;
    
    	
    	$scope.search = userSvc.search;
    	
    		
    	 
    	 $scope.$on('$viewContentLoaded', function(){
    		  // alert("search view content loaded3");
    		 if (userSvc.search.history == 'daterange'){
    		    $('#fromDate').css('display','');
    		    $('#toDate').css('display','');
    		 } else {
    			 $('#fromDate').css('display','none');
    			 $('#toDate').css('display','none');
    		 }
    		 
    		 if (userSvc.search.category == '') {
    			 userSvc.search.category = 'ALL';
    		 }
    		 
    		//  $("#remark").val(userSvc.search.category);
    		    
    		  });
        	
    	/*
    	function searchSuccessCbk(data) {
	    	 // alert("in search response success3");
	    	 userSvc.searchResultsObj = data;
	    	 $rootScope.$apply(function() {
				 var submitPathUrl = "/list";
				 // alert("submitPathUrl:"+submitPathUrl);
				 $location.path(submitPathUrl);	      		
	    	 });
	    	 
    	}
    	*/
    	
    	
    	/*
    	Displays and hides the date pickers according to the selected option in the history field
    */
    $scope.updateDateRange = function (){
        //alert("in update date range method");
        //alert("history value:"+$scope.search.history);
    	// var length = document.getElementById("history").length;

        
    	if($scope.search.history == 'daterange'){
    		document.getElementById("fromDate").style.display='';		
    		document.getElementById("toDate").style.display='';
    	}else {
    		document.getElementById("fromDate").style.display='none';
    		document.getElementById("toDate").style.display='none';

    		document.getElementById("from").value='';
    		document.getElementById("to").value='';
    	}
    };    	
    
    $scope.gotoDownline = function() {
    	var submitUrl = getDownlineUrl;
		// var paramUserId = userSvc.userInfo.userId;		
		// submitUrl += "?" + "paramUserId="+paramUserId;
		
		$("#spinner").html(spinImg);
		// $("#spinner").html('testspin3');
		
		 $http.get(submitUrl).success(function(data) {
			 
			 // handle for session expired
			 if (isSessionExpired(data)){
				$("#spinner").html('&nbsp;');
				alert("Your session has expired. Please login again."); 				
				window.location = cmodRenderUrl;
				return;
			 } 
			 
			 // handle for error
			 if (isProcessingError(data)) {
				 $("#spinner").html('&nbsp;');
				 $location.path('/error');
				 
				 return;
			 }
			 
			 userSvc.downlineResultsObj = data;
		      
			 // reset downline selected Agent
		      userSvc.selectedAgentContainer = {};
		      userSvc.selectedAgentContainer.selectedAgentObj = {logonId:'',firstName:'',lastName:'',email:''};
			 
			 $("#spinner").html('&nbsp;');
			 $location.path('/downline');	
		  });
    	
    };      
     
    
      // submit types - FormSearch, QuickCategorySearch, QuickReportNameSearch, DownlineSearch
	  $scope.submitSearch = function(submitType,submitName) {
		  // alert("in submit search5");
		  var submitUrl = submitGetReportsListUrl;
		  		  
		  var formErrorF = false;
		  if ((submitType == 'FormSearch') && ($scope.search.history == 'daterange')) {
			  if($scope.searchForm.$invalid) {
				  // alert("Please fix errors before submitting.");
				  formErrorF = true;
				  $scope.searchMsg  = {error : {fix: true}};
				  return;
			  }				  
		  }
		  
		  if (!formErrorF) {
			  $scope.searchMsg  = {error : {fix: false}};
		  } 
		  
		  // var myval2 = $filter('date')(new Date('Fri Nov 06 2015 00:00:00 GMT-0600 (Central Standard Time)'),'yyyy-MM-dd');
		  
		  $("#spinner").html(spinImg);
		  
		  // tbdv quick links submit - reportName, categorySearch
		  userSvc.search.submitType = submitType;
		  
		   
		  // userSvc.downlineSelectedObj.downlineSelectedAgent = '';
		  if (submitType == 'QuickReportNameSearch') { 	// "SL PROD SUMMARY", "EXP TERM CONV LTR"			  
			  userSvc.search.reportName = submitName;
			  userSvc.search.category = "";
			  userSvc.search.policyNum = "";
			  userSvc.search.history = "available"; // "daterange";			  
			  userSvc.search.fromDate = ""; //  getDefaultFromDate();	
			  userSvc.search.toDate = ""; // getDefaultToDate();
			  if (userSvc.userInfo.managerFlag) {
				  userSvc.search.userSearchType = "hierarchy";  
			  } else {
				  userSvc.search.userSearchType = "personal";
			  }			  
		  } else if (submitType == 'QuickCategorySearch') {
			  userSvc.search.reportName = "";
			  userSvc.search.category = submitName;			  
			  userSvc.search.policyNum = "";
			  userSvc.search.history = "available"; // "daterange";			  
			  userSvc.search.fromDate = "";  // getDefaultFromDate();	
			  userSvc.search.toDate = ""; // getDefaultToDate();
			  if (userSvc.userInfo.managerFlag) {
				  userSvc.search.userSearchType = "hierarchy";  
			  } else {
				  userSvc.search.userSearchType = "personal";
			  }
		  } else {  // FormSearch
			  userSvc.search.reportName = "";
			  userSvc.search.category = $scope.search.category;
			  userSvc.search.history = $scope.search.history;   // all available or date range
			  var fromDate = $scope.search.fromDate;	
			  if (fromDate) {
				  var formatFromDate = $filter('date')(new Date(fromDate),'MM/dd/yyyy');  
			  } else {
				  var formatFromDate = "";
			  }			  
			  userSvc.search.fromDate = formatFromDate;
			  //userSvc.search.fromDate =  $filter('date')(fromDate,'yyyy-MM-dd',null);
			  // alert("filteredDate:"+userSvc.search.fromDate);
			  var toDate = $scope.search.toDate;
			  if (toDate) {
				  var formatToDate = $filter('date')(new Date(toDate),'MM/dd/yyyy');  
			  } else {
				  var formatToDate = "";
			  }			  
			  userSvc.search.toDate = formatToDate;
			  userSvc.search.policyNum = $scope.search.policyNum;		
			  if (userSvc.userInfo.managerFlag) {
				  userSvc.search.userSearchType = $scope.search.userSearchType;  
			  } else {
				  userSvc.search.userSearchType = "personal";
			  }
			  			  
		  }
		  		  		  
		  // var paramUserId = userSvc.userInfo.userId;
		  // submitUrl += "?" + "paramUserId="+paramUserId;
		  submitUrl += "?paramSubmitType="+userSvc.search.submitType;
		  if (submitType == 'QuickReportNameSearch') {
			  var paramReportName = encodeURIComponent(userSvc.search.reportName);
			  submitUrl += "&paramReportName="+paramReportName;
		  } else {
			  submitUrl += "&paramCategory="+userSvc.search.category;  
		  }
		  submitUrl += "&paramHistory="+userSvc.search.history;
		  submitUrl += "&paramFromDate="+userSvc.search.fromDate;
		  submitUrl += "&paramToDate="+userSvc.search.toDate;
		  submitUrl += "&paramPolicyNum="+userSvc.search.policyNum;
		  submitUrl += "&paramUserSearchType="+userSvc.search.userSearchType;
		  		   
		  // alert ("userSvc.search:"+userSvc.search);
		  // alert("search policyNum:"+userSvc.search.policyNum);		  
		  // var searchCmodUrl = "http://an36882.dnanico1.aniconet.com:10080/CmodProj/adapters/CmodAdapter/cmodSvc/searchCmod";
		 
		  /*  METHOD 1 */
		  
		 $http.get(submitUrl).success(function(data) {
			 
			 // handle for session expired
			 if (isSessionExpired(data)){
				$("#spinner").html('&nbsp;');
				alert("Your session has expired. Please login again."); 				
				window.location = cmodRenderUrl;
				return;
			 } 
			 
			 // handle for error
			 if (isProcessingError(data)) {
				 $("#spinner").html('&nbsp;');
				 $location.path('/error');
				 
				 return;
			 }
			 
			 userSvc.searchResultsObj = data;
			 $("#spinner").html('&nbsp;');
			 $location.path('/list');	
		  });
		
		  
		 
	  };
	  
	  
	  
		$scope.datePickers = {};
		
		$scope.getDatePicker = function(datePicker) {
			if ($scope.datePickers[datePicker] === undefined) {
				$scope.datePickers[datePicker] = { open : false };
			}
			return $scope.datePickers[datePicker];
		};

		$scope.toggleOpenDatePicker = function($event, _datePicker) {
			$event.preventDefault();
			$event.stopPropagation();
		
			var datePicker = $scope.getDatePicker(_datePicker);
			datePicker.open = !datePicker.open;
		};

		$scope.validatePastDate = function(value) {
			if (value !== undefined) {
				var now = new Date();
				now.setHours(23, 59, 59, 999);

				return value < now;
			}
			return true;
		};

		$scope.validateCurrentOrFutureDate = function(value) {
			if (value !== undefined) {
				var now = new Date();
				now.setHours(0, 0, 0, 0);

				return value >= now;
			}
			return true;
		};
	
		// start search over here	
		if (viewReportsOnStartFlag) {
			if (startAppCallF) {
				// alert("in start app call true");
				userSvc.search.policyNum = startPolicynum;
				userSvc.search.category = startCategory;								
   			    if (userSvc.userInfo.managerFlag) {
				   userSvc.search.userSearchType = "hierarchy";  
			     } else {
				   userSvc.search.userSearchType = "personal";
		    	 }
   			    
				$scope.submitSearch('FormSearch',null);
			} else {
				if (startSubmitType == 'QuickCategorySearch') {
					$scope.submitSearch(startSubmitType,startCategory);
				} else if (startSubmitType == 'QuickReportNameSearch') {
					$scope.submitSearch(startSubmitType,startReportName);
				} else {
					; // do nothing
				}					
			}
					
		}
	    viewReportsOnStartFlag = false;
	  
	});






cmodControllerMod.controller('cmodListCtrl', function ($scope,$http,$location,appSvc,userSvc,uiGridConstants) {
	// alert("in cmod list ctrl 2n");
    $scope.viewName = "Cmod List View";
    $scope.userInfo = userSvc.userInfo;
    
    $scope.searchResultsObj = userSvc.searchResultsObj;
    $scope.search = userSvc.search;
    // $scope.downlineSelectedObj = userSvc.downlineSelectedObj;
    $scope.selectedAgentContainer = userSvc.selectedAgentContainer;
    
    /*
     $scope.items =  $http.get('json/testReportList.json').success(function(data) {
 	    $scope.rptList = data;
	  });
	 */
    

    
   
    
    $scope.showReport = function(rptName,rptDate,rptDocType,rptAppName,rptCategory,rptPolicyNum) {
    	// alert("in showReport rptName:"+rptName+" \nrptHnd:"+rptHnd);
    
    	userSvc.selectedRptObj.rptName = rptName; 
        userSvc.selectedRptObj.rptDate = rptDate;
        userSvc.selectedRptObj.rptDocType = rptDocType;
        userSvc.selectedRptObj.rptAppName = rptAppName;
        userSvc.selectedRptObj.rptCategory = rptCategory;
        userSvc.selectedRptObj.rptPolicyNum = rptPolicyNum;
        
        // userSvc.selectedRptObj.rptHnd = rptHnd;
        // userSvc.selectedRptObj.rptAppGroupName = rptAppGroupName;
        // userSvc.selectedRptObj.rptApplicationName = rptApplicationName;
    	
        $location.path("/rpt");
    }    


    
    $scope.downloadReport = function(rptName,rptDate,rptDocType,rptAppName,rptCategory,rptPolicyNum) {
    	// alert("in downloadReport rptName:"+rptName+" \nrptHnd:"+rptHnd);
    	
    	var submitUrl = downloadReportUrl;
    	// submitUrl += "?" + "paramUserId=" + userSvc.userInfo.userId;
    	var encodedParamRptName = encodeURIComponent(rptName);
	    submitUrl += "?" + "paramRptName="+encodedParamRptName;
	    submitUrl += "&" + "paramRptDate="+rptDate;
	    submitUrl += "&" + "paramRptCategory="+rptCategory;
	    submitUrl += "&" + "paramRptPolicyNum="+rptPolicyNum;
	    submitUrl += "&" + "paramRptAppName="+rptAppName;
	    submitUrl += "&" + "paramSearchType="+rptDocType;
	    submitUrl += "&" + "paramSubmitType="+userSvc.search.submitType;
	    submitUrl += "&" + "paramDownlineAgent="+userSvc.selectedAgentContainer.selectedAgentObj.logonId;

	    
	    window.location = submitUrl;
    };
    
    $scope.checkReport = function() {
    	alert("in check report");
    }
    
    // setup list grid
    function cellTemplateRptName() {
    	var str = '<div class="ui-grid-cell-contents" title="TOOLTIP">'
    		+' <a href="#" ng-click="$event.preventDefault();'
    		+ ' grid.appScope.showReport(row.entity.reportName,row.entity.reportDate,row.entity.docType,row.entity.applicationName,row.entity.categoryID,row.entity.policyNumber)">'
    		+ '{{COL_FIELD CUSTOM_FILTERS}}'
    		+ '</a>'    	
    		 +'</div>';
   
    	
    	return str;
    }

    function cellTemplateRptDate() {
    	var str = '<div class="ui-grid-cell-contents" title="TOOLTIP">'
    		 +'{{COL_FIELD CUSTOM_FILTERS}}'
    		 +'</div>';
    	return str;
    }

    function cellTemplateRptType() {
    	var str = '<div class="ui-grid-cell-contents" title="TOOLTIP">'
    		 +'{{((COL_FIELD=="P")?"PERSONAL":"HIERARCHY") CUSTOM_FILTERS}}'
    		 +'</div>';
    	return str;
    }    
    
    function cellTemplateRptDownload() {    	
    	var str = '<div class="ui-grid-cell-contents" title="TOOLTIP">'
    		+' <a href="#" ng-click="$event.preventDefault();'
    		+ ' grid.appScope.downloadReport(row.entity.reportName,row.entity.reportDate,row.entity.docType,row.entity.applicationName,row.entity.categoryID,row.entity.policyNumber)">'
    		// +  ' <img src="images/mysave.png" alt="Save Report" border="0px" />'    		
    		+  ' <img src="' + cmodBaseUrl + '/images/mysave.png" alt="Save Report" border="0px" />'
    		+ ' </a>'    	
    		 +'</div>';
    		
    	return str;
    }

    
    var dataListArr = $scope.searchResultsObj.resultData.reportsList;

    $scope.gridOptionsList = {
    	    paginationPageSizes: [10, 20, 50, 100],
    	    paginationPageSize: 10,
    		data : dataListArr,
    	    // enableSorting: true,
    	    // enableFiltering: true,
    	    // enablePaginationControls: true,	    
    	    columnDefs: [
    	                 { field: 'reportName', 
    	                   displayName: 'NAME', 
    	                   type: 'string',    	 
    	                   width: '45%',
    	                   cellTemplate: cellTemplateRptName() 
    	                 },
    	                 
    	                 { field: 'reportDate', 
    	                   displayName: 'DATE',
    	                   type: 'date',
    	                   width: '20%',
    	                   sort: {direction: uiGridConstants.DESC,priority: 1},
    	                   cellTemplate: cellTemplateRptDate() 
    	                 },
    	                 
       	                 { field: 'docType', 
    	                   displayName: 'TYPE',
    	                   type: 'string',
    	                   width: '20%',
        	               cellTemplate: cellTemplateRptType() 
        	             },
        	             
    	                 { name: 'DownloadCol',displayName: '',
        	               width: '15%',
        	               enableSorting: false, 
        	               enableFiltering: false,
    	                   cellTemplate: cellTemplateRptDownload()
    	                 }
    	             
    	                 // { field: 'company', displayName: 'Company Name', enableSorting: false, enableFiltering: false }
    	                ]
    	   
     };    
    

    
    
});




/*
     	userSvc.selectedRptObj.rptName = rptName; 
        userSvc.selectedRptObj.rptDate = rptDate;
        userSvc.selectedRptObj.rptDocType = rptDocType;
        userSvc.selectedRptObj.rptAppName = rptAppName;
        userSvc.selectedRptObj.rptCategory = rptCategory;

 */


cmodControllerMod.controller('rptCtrl', function ($scope,appSvc,userSvc) {
	// alert("in rpt ctrl2:"+userSvc.selectedRptObj.rptName);
    $scope.viewName = "Report View";	
    $scope.userInfo = userSvc.userInfo;
 
    // showreport
	var docUrl = showReportUrl;
	// docUrl += "?" + "paramUserId=" + userSvc.userInfo.userId;	
	var rptName = userSvc.selectedRptObj.rptName;
	var encodedParamRptName = encodeURIComponent(rptName);
    docUrl += "?" + "paramRptName="+encodedParamRptName;
    docUrl += "&" + "paramRptDate="+userSvc.selectedRptObj.rptDate;
    docUrl += "&" + "paramSearchType="+userSvc.selectedRptObj.rptDocType;
    docUrl += "&" + "paramRptCategory="+userSvc.selectedRptObj.rptCategory;
    docUrl += "&" + "paramRptPolicyNum="+userSvc.selectedRptObj.rptPolicyNum;
    docUrl += "&" + "paramRptAppName="+userSvc.selectedRptObj.rptAppName;
    docUrl += "&" + "paramSubmitType="+userSvc.search.submitType;
    docUrl += "&" + "paramDownlineAgent="+userSvc.selectedAgentContainer.selectedAgentObj.logonId;
    
    // alert("load using object");
   //  alert("load using iframe");
    
    // var rptLink = "pdfs/ADMREQS.pdf";
    
    // $("#rptDisplayDiv").append('<object data="' +  rptLink + '" type="application/pdf" width="100%" height="700px"><div id="error">The report you are trying to view is not available.</div></object>');
    
	var pluginActiveF = appSvc.isPDFPluginActive();
	
	if(pluginActiveF){
		// alert("in pdf plugin active");		
		// $("#rptDisplayDiv").append();
		
		// var docUrl = "http://an36882.dnanico1.aniconet.com:10080/CmodProj/apps/services/preview/CmodApp/common/0/default/pdfs/ADMREQS.pdf";
		// docUrl = "http://an36882.dnanico1.aniconet.com:10080/CmodProj/apps/services/preview/CmodApp/common/0/default/pdfs/test1.pdf";
		
		// previous code
		// var docUrl = cmodBaseUrl + "/" + rptLink;
		
		
		// original call
		/*
		rptStr = '<object data="' + docUrl 
		+ '" type="application/pdf" width="100%" height="700px"><div id="error">The report you are trying to view is not available.</div></object>';
		*/
		
		/* new call */
		rptStr = 
		'<div id="pdf"><iframe src="'
		+docUrl
		+'" style="width: 100%; height: 700px;" frameborder="0" scrolling="no">'
		+'<p>It appears your web browser does not support iframes.</p>'
	    +'</iframe>'
		+'</div>';
		
		
		// alert("rptStr4:"+rptStr);
		// $("#rptDisplayDiv").append(rptStr);
		var rptDivObj = document.getElementById("rptDisplayDiv");
		rptDivObj.innerHTML = rptStr;
		
		// window.open(docUrl);
		// window.open(rptLink);
		// window.open("http://www.anico.com");
	    // alert("after pdf plugin active");
	//otherwise, we launch a new window to open up the report
	}else{
		// alert("in pdf plugin not active");
		// window.open($(link).attr("href"));
		window.open(docUrl);
		// alert("after pdf plugin not active");
	}
    
});



//downline reports
cmodControllerMod.controller('downlineCtrl', function ($scope,$interval,$rootScope,$http,$location,appSvc,userSvc,$filter,uiGridConstants) {
	// alert("in rpt ctrl2:"+userSvc.selectedRptObj.rptName);
    $scope.viewName = "Downline View";	
    $scope.userInfo = userSvc.userInfo;
    
    $scope.categories = appSvc.categories;    
    $scope.search = userSvc.search;
    
    $scope.downlineResultsObj = userSvc.downlineResultsObj;
    
    /*
    var numDownline = userSvc.downlineResultsObj.resultNum;
    var downlineSelectedAgent = userSvc.downlineSelectedObj.downlineSelectedAgent;
    if (numDownline > 0) {
    	if (downlineSelectedAgent == '') {
    		userSvc.downlineSelectedObj.downlineSelectedAgent = userSvc.downlineResultsObj.resultData[0].logonId;	
    	}   else {
    		userSvc.downlineSelectedObj.downlineSelectedAgent = downlineSelectedAgent;
    	} 	
    } else  {
    	userSvc.downlineSelectedObj.downlineSelectedAgent = '';
    }
    $scope.downlineSelectedObj = userSvc.downlineSelectedObj;
    */
    
    
    // selected agent entity
    /*
    var selectedAgentObj = userSvc.selectedAgentContainer.selectedAgentObj;
    if (numDownline > 0) {
    	if ((selectedAgentObj) && (selectedAgentObj.logonId == '')) {
    		userSvc.selectedAgentContainer.selectedAgentObj = userSvc.downlineResultsObj.resultData[0];    		
    	}
    }
    */ 
    
    $scope.selectedAgentContainer = userSvc.selectedAgentContainer;    
   
    
	 $scope.$on('$viewContentLoaded', function(){
		  // alert("search view content loaded3");
		 if (userSvc.search.history == 'daterange'){
		    $('#fromDate').css('display','');
		    $('#toDate').css('display','');
		 } else {
			 $('#fromDate').css('display','none');
			 $('#toDate').css('display','none');
		 }
		 
		 if (userSvc.search.category == '') {
			 userSvc.search.category = 'ALL';
		 }
		 
		 
		 
		  // $scope.gridApi.core.scrollTo( $scope.selectedAgentContainer.selectedAgentObj, $scope.gridOptionsDownline.columnDefs[0]);
		  
		  });
	 
	 
 /*
 	Displays and hides the date pickers according to the selected option in the history field
 */
 $scope.updateDateRange = function (){
     //alert("in update date range method");
     //alert("history value:"+$scope.search.history);
 	// var length = document.getElementById("history").length;

     
 	if($scope.search.history == 'daterange'){
 		document.getElementById("fromDate").style.display='';		
 		document.getElementById("toDate").style.display='';
 	}else {
 		document.getElementById("fromDate").style.display='none';
 		document.getElementById("toDate").style.display='none';

 		document.getElementById("from").value='';
 		document.getElementById("to").value='';
 	}
 };  		 

 

 $scope.submitSearchDownlineTest = function(submitType) {
	  // alert("in downline scroll3");
	 $scope.gridApi.core.scrollTo( $scope.selectedAgentContainer.selectedAgentObj, $scope.gridOptionsDownline.columnDefs[0]);
	 // $scope.gridApi.core.scrollTo( $scope.gridOptionsDownline.data[15], $scope.gridOptionsDownline.columnDefs[0]);
	 $scope.gridApi.cellNav.getCurrentSelection();
	 // alert("in downline scroll4");
 };	 
    
    // submit types - FormSearch, QuickCategorySearch, QuickReportNameSearch, DownlineSearch
	  $scope.submitSearchDownline = function(submitType) {
		  // alert("in downline search4");
		  var submitUrl = submitGetReportsListUrl;
		  		  
		  var formErrorF = false;
		  if ((submitType == 'DownlineSearch') && ($scope.search.history == 'daterange')) {
			  if($scope.downlineForm.$invalid) {
				  // alert("Please fix errors before submitting.");
				  formErrorF = true;
				  $scope.downlineMsg  = {error : {fix: true}};
				  return;
			  }				  
		  }
		  
		  if (!formErrorF) {
			  $scope.downlineMsg  = {error : {fix: false}};
		  } 		  
		  
		  // alert("submitType is:"+submitType);
		  userSvc.search.submitType = submitType;		  
		  
		  // alert("downlineSelectedAgent is:"+$scope.downlineSelectedObj.downlineSelectedAgent);
		  // userSvc.downlineSelectedObj.downlineSelectedAgent = $scope.downlineSelectedObj.downlineSelectedAgent;	
		  userSvc.selectedAgentContainer = $scope.selectedAgentContainer;
		  
		  
		  $("#spinner").html(spinImg);
		  
		  userSvc.search.reportName = "";
		  userSvc.search.category = $scope.search.category;
		  userSvc.search.history = $scope.search.history;   // all available or date range
		  var fromDate = $scope.search.fromDate;		  
		  userSvc.search.fromDate = fromDate;
		  //userSvc.search.fromDate =  $filter('date')(fromDate,'yyyy-MM-dd',null);
		  // alert("filteredDate:"+userSvc.search.fromDate);
		  userSvc.search.toDate - $scope.search.toDate;
		  userSvc.search.policyNum = $scope.search.policyNum;
		  userSvc.search.userSearchType = 'personal';

		  // var paramUserId = userSvc.userInfo.userId;
		  // submitUrl += "?" + "paramUserId="+paramUserId; $("spinner").innerHTML = spinImg;
		  submitUrl += "?paramSubmitType="+userSvc.search.submitType;
		  submitUrl += "&paramCategory="+userSvc.search.category;  
		  submitUrl += "&paramHistory="+userSvc.search.history;
		  submitUrl += "&paramFromDate="+userSvc.search.fromDate;
		  submitUrl += "&paramToDate="+userSvc.search.toDate;
		  submitUrl += "&paramPolicyNum="+userSvc.search.policyNum;
		  // submitUrl += "&paramDownlineAgent="+userSvc.downlineSelectedObj.downlineSelectedAgent;
		  submitUrl += "&paramDownlineAgent="+userSvc.selectedAgentContainer.selectedAgentObj.logonId;
		  
		  // submitUrl += "&paramUserSearchType="+userSvc.search.userSearchType;

		  $http.get(submitUrl).success(function(data) {
			 userSvc.searchResultsObj = data;
			 $("#spinner").html('&nbsp;');
			 $location.path('/list');	
		  });
			 
			 
	  };
	  
	  
	  
	    function cellTemplateBasic() {
	    	var str = '<div class="ui-grid-cell-contents" title="TOOLTIP">'
	    		 +'{{COL_FIELD CUSTOM_FILTERS}}'
	    		 +'</div>';
	    	return str;
	    }	  
	  

	  
	    function cellTemplateListName() {	    
	    	var str = '<div class="ui-grid-cell-contents" title="TOOLTIP">'
	    		+' {{row.entity.firstName}} {{row.entity.lastName}} '    	
	    		 +'</div>';
	    		    	
	    	return str;
	    }	
	    
    
	    
	  	    
	    function cellTemplateListSelect() {    	
	    	var str = '<div class="ui-grid-cell-contents"  title="TOOLTIP">'
	    		+' <input type="radio"  style="border-width:0px;" ng-value="row.entity" ng-model="grid.appScope.selectedAgentContainer.selectedAgentObj"/> '   	
	    		 +'</div>';
	    		
	    	return str;
	    }	    

	    
	  
	    // var dataListArr = $scope.searchResultsObj.resultData.reportsList;
	    var dataListArr = $scope.downlineResultsObj.resultData;
	    // TODO - js grid options
	    // tbdv - gridOptionsDownline
	    $scope.gridOptionsDownline = {
	    	    // paginationPageSizes: [10, 20, 50,100],
	    	    // paginationPageSize: 10,
	    		data : dataListArr,
	    	    columnDefs: [
	    	              { name: 'SelectCol',
	    	            	displayName: '',
	          	            enableSorting: false, 
	          	            enableFiltering: false,
	          	            width: '10%',
	      	                cellTemplate: cellTemplateListSelect()
	                      },
	                      
	    	              { 
	    	            	field: 'logonId', 
	    	                displayName:'AGENT ID',
	    	                type: 'string',
	    	                width: '30%',
	    	                sort: {direction: uiGridConstants.ASC,priority:2},
	    	                sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
	    	              },
	    	                 
	    	             { 
	    	               name: 'fullName',
	    	               // field: 'firstName', 
	    	               displayName: 'NAME',
	    	               type: 'string',
	    	               width: '60%',	    	          
	                       cellTemplate: cellTemplateListName(),
	                       sort: {direction: uiGridConstants.ASC,priority:1},
	                       sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
	                     }
	    	     ],
	    	     onRegisterApi: function( gridApi ) {
	    	    	 $scope.gridApi = gridApi;
	    	    	 // $scope.gridApi.core.scrollTo( $scope.selectedAgentContainer.selectedAgentObj, $scope.gridOptionsDownline.columnDefs[0]);
	    	    	 // $scope.gridApi.cellNav.scrollToFocus();
	    	         gridApi.cellNav.on.navigate($scope,function(newRowCol, oldRowCol){
	    	             // var rowCol = {row: newRowCol.row.index, col:newRowCol.col.colDef.name};
	    	             // var msg = 'New RowCol is ' + angular.toJson(rowCol);
	    	             // if(oldRowCol){
	    	             //    rowCol = {row: oldRowCol.row.index, col:oldRowCol.col.colDef.name};
	    	             //    msg += ' Old RowCol is ' + angular.toJson(rowCol);
	    	             // }
	    	              // $log.log('navigation event');
	    	        	 var a = 1;
	    	            });  
	    	         
	    	         
	    	         
	    	         // test this 
	    	         /*
	    	            $scope.gridApi.core.on.rowsRendered($scope, function() {
	    	            	$scope.gridApi.core.scrollTo( $scope.selectedAgentContainer.selectedAgentObj, $scope.gridOptionsDownline.columnDefs[0]);	    	            	
	    	            });
	    	           */
	    	         
	    	            var myFn = function() {	    	            	
	    	            	$scope.gridApi.core.scrollTo( $scope.selectedAgentContainer.selectedAgentObj, $scope.gridOptionsDownline.columnDefs[0]);
	    	            };

	    	            $scope.gridApi.core.on.renderingComplete($scope,function() {	    	            	
	    	            	// $scope.gridApi.core.scrollTo( $scope.selectedAgentContainer.selectedAgentObj, $scope.gridOptionsDownline.columnDefs[0]);
	    	            	 $interval(myFn,1,1);
	    	            	// $scope.gridApi.grid.redrawInPlace();
	    	            });


	    	            
	    	            var rowsProcessorFn = function(renderedRowsToProcess, columns) {
	    	                var selectedAgentObj = userSvc.selectedAgentContainer.selectedAgentObj;
	    	                var numDownline = 0;
	    	                if (renderedRowsToProcess) {
	    	                	numDownline = renderedRowsToProcess.length;	
	    	                }
	    	                
	    	                if (numDownline > 0) {
	    	                	if ((selectedAgentObj) && (selectedAgentObj.logonId == '')) {
	    	                		userSvc.selectedAgentContainer.selectedAgentObj = renderedRowsToProcess[0].entity;    		
	    	                	}
	    	                } 
	    	                $scope.selectedAgentContainer = userSvc.selectedAgentContainer;    

	    	            	return renderedRowsToProcess;
	    	            };
	    	            
	    	            $scope.gridApi.core.registerRowsProcessor(rowsProcessorFn,700);
	    	            
	    	     	}
	    
	     };    
	    
	        
	    
		$scope.datePickers = {};
		
		$scope.getDatePicker = function(datePicker) {
			if ($scope.datePickers[datePicker] === undefined) {
				$scope.datePickers[datePicker] = { open : false };
			}
			return $scope.datePickers[datePicker];
		};

		$scope.toggleOpenDatePicker = function($event, _datePicker) {
			$event.preventDefault();
			$event.stopPropagation();
		
			var datePicker = $scope.getDatePicker(_datePicker);
			datePicker.open = !datePicker.open;
		};

		$scope.validatePastDate = function(value) {
			if (value !== undefined) {
				var now = new Date();
				now.setHours(23, 59, 59, 999);

				return value < now;
			}
			return true;
		};

		$scope.validateCurrentOrFutureDate = function(value) {
			if (value !== undefined) {
				var now = new Date();
				now.setHours(0, 0, 0, 0);

				return value >= now;
			}
			return true;
		};
		
		/*
		var endDownlineFn = function() {
			$scope.gridApi.core.scrollTo( $scope.selectedAgentContainer.selectedAgentObj, $scope.gridOptionsDownline.columnDefs[0]);				
		};
		
		endDownlineFn();
	    */
	  
    // alert("in downline view");        
});




cmodControllerMod.controller('cmodTestListCtrl', function ($scope,$http,$location,userSvc) {
	// alert("in cmod list ctrl 2n");
    $scope.viewName = "Cmod Test List View";
    $scope.userInfo = userSvc.userInfo;
    
    $scope.rptList = resultsRptList;
    
    /*
     $scope.items =  $http.get('json/testReportList.json').success(function(data) {
 	    $scope.rptList = data;
	  });
	 */
    
    $scope.showSelectReport = function(rptHndParam) {
    	// alert("in showSelectReport rptHnd:"+rptHndParam);
    	rptHnd = rptHndParam;
    	$location.path("/rpt");	
    }
    
    
    
});


cmodControllerMod.controller('tabsCtrl', function ($scope,appSvc,userSvc) {
	// alert("in cmod tabs ctrl");
    $scope.viewName = "Tabs View";
    $scope.userInfo = userSvc.userInfo;
    
});


cmodControllerMod.controller('gridCtrl', function ($scope,appSvc,userSvc,uiGridConstants) {
	// alert("in cmod grid ctrl");
    $scope.viewName = "Grid View0";		
    $scope.userInfo = userSvc.userInfo;
    
    var dataArr = [
                     {"firstName": "Cox", "lastName": "Carney", "company": "Enormo"},
                     {"firstName": "Lorraine","lastName": "Wise","company": "Comveyer"},
                     {"firstName": "Nancy","lastName": "Waters","company": "Fuelton"},
                     {"firstName": "Fred", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Jane", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Jack", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "John", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Nancy", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Cox", "lastName": "Carney", "company": "Enormo"},
                     {"firstName": "Lorraine","lastName": "Wise","company": "Comveyer"},
                     {"firstName": "Nancy","lastName": "Waters","company": "Fuelton"},
                     {"firstName": "Fred", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Jane", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Jack", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "John", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Nancy", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Cox", "lastName": "Carney", "company": "Enormo"},
                     {"firstName": "Lorraine","lastName": "Wise","company": "Comveyer"},
                     {"firstName": "Nancy","lastName": "Waters","company": "Fuelton"},
                     {"firstName": "Fred", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Jane", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Jack", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "John", "lastName": "Smith", "company": "Acme"},
                     {"firstName": "Nancy", "lastName": "Smith", "company": "Acme"}                     
                  ];
    
    $scope.myData = dataArr;
    
    function cellTemplate1() {
    	var str = '<div class="ui-grid-cell-contents" title="TOOLTIP">'
    		 +' abc {{COL_FIELD CUSTOM_FILTERS}}' + ' ' + '{{row.entity.company}} '
    		 +'</div>';    
    	
    	return str;
    }

    function cellTemplate2() {
    	var str = '<div class="ui-grid-cell-contents" title="TOOLTIP">'
    		 +' def {{COL_FIELD }}' + ' foo2'
    		 +'</div>';
    	return str;
    }
    
    
    $scope.gridOptions1 = {
    	    paginationPageSizes: [3, 4, 5],
    	    paginationPageSize: 4,
    		data : dataArr,
    	    // enableSorting: true,
    	    // enableFiltering: true,
    	    // enablePaginationControls: true,	    
    	    columnDefs: [
    	                 { field: 'firstName', sort: {direction: uiGridConstants.ASC,priority: 1},
    	                	 cellTemplate: cellTemplate1() },
    	                 { field: 'lastName', sort: {direction: uiGridConstants.ASC,priority: 2},
    	                	 cellTemplate: cellTemplate2() }
    	             
    	                 // { field: 'company', displayName: 'Company Name', enableSorting: false, enableFiltering: false }
    	                ]
    	     
    	    /*            
    	    onRegisterApi: function( gridApi ) {
    	      $scope.grid1Api = gridApi;
    	    } 
    	    */
     };    
    
                     

});



cmodControllerMod.controller('headerCtrl', function ($scope,$modal,appSvc,userSvc) {
	// alert("in cmod header ctrl");
    $scope.viewName = "Header View";
    $scope.userInfo = userSvc.userInfo;
    
    $scope.selectedUserId = userSvc.userInfo.userId; 
    
    $scope.signIn = function(size) {
    	// alert("in signin method");
    	
        var modalInstance = $modal.open({
            animation: $scope.animationsEnabled,
            templateUrl: cmodBaseUrl + '/views/loginView.html',
            controller: 'ModalInstanceCtrl',
            size: size,
            
            /*
            resolve: {
                loginModel : function() {
                    return $scope.loginModel;
                }
            }
            */
        });

        modalInstance.result.then(function(enteredObj) {
            userSvc.userInfo.userId = enteredObj.userId;
            $scope.selectedUserId = userSvc.userInfo.userId;
            // $scope.go('scanit.dashboard');
        }, function() {
            console.log('Modal dismissed at: ' + new Date());
        });    	
    };

    
});



cmodControllerMod.controller('ModalInstanceCtrl', function($scope, $modalInstance,appSvc,userSvc) {
	$scope.userInfo = userSvc.userInfo;
	
    $scope.loginModel = {
        userId: userSvc.userInfo.userId,
        password: userSvc.userInfo.pwd
    };
    
	
	$scope.viewName = "Modal View";

    $scope.ok = function() {
        // scopeParent.serviceInput.requester = $scope.loginModel.requester;
        // scopeParent.serviceInput.password = $scope.loginModel.password;
        // scopeParent.submitRequest();
        $modalInstance.close(this.loginModel);
    };

    $scope.cancel = function() {
        $modalInstance.dismiss('cancel');
    };

    $scope.close = function() {
        $modalInstance.close();
    };
});






cmodControllerMod.controller('dateCtrl', function ($scope) {

	  $scope.today = function() {
	    $scope.dt = new Date();
	  };
	  $scope.today();

	  $scope.clear = function () {
	    $scope.dt = null;
	  };

	  // Disable weekend selection
	  $scope.disabled = function(date, mode) {
	    return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
	  };

	  $scope.toggleMin = function() {
	    $scope.minDate = $scope.minDate ? null : new Date();
	  };
	  $scope.toggleMin();
	  $scope.maxDate = new Date(2020, 5, 22);

	  $scope.open = function($event) {
	    $scope.status.opened = true;
	  };

	  $scope.setDate = function(year, month, day) {
	    $scope.dt = new Date(year, month, day);
	  };

	  $scope.dateOptions = {
	    formatYear: 'yy',
	    startingDay: 1
	  };

	  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
	  $scope.format = $scope.formats[0];

	  $scope.status = {
	    opened: false
	  };

	  var tomorrow = new Date();
	  tomorrow.setDate(tomorrow.getDate() + 1);
	  var afterTomorrow = new Date();
	  afterTomorrow.setDate(tomorrow.getDate() + 2);
	  $scope.events =
	    [
	      {
	        date: tomorrow,
	        status: 'full'
	      },
	      {
	        date: afterTomorrow,
	        status: 'partially'
	      }
	    ];

	  $scope.getDayClass = function(date, mode) {
	    if (mode === 'day') {
	      var dayToCheck = new Date(date).setHours(0,0,0,0);

	      for (var i=0;i<$scope.events.length;i++){
	        var currentDay = new Date($scope.events[i].date).setHours(0,0,0,0);

	        if (dayToCheck === currentDay) {
	          return $scope.events[i].status;
	        }
	      }
	    }

	    return '';
	  };
	});




cmodControllerMod.controller('cmodErrorCtrl', function ($scope,$location,appSvc,userSvc) {
	// alert("in cmod error ctrl 2n");
    $scope.viewName = "Cmod Error View";
    $scope.userInfo = userSvc.userInfo;
	
});    

// alert('controller js end');
