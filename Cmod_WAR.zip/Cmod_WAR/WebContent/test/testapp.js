

var testNgApp = angular.module('testNgApp', [
  'ngRoute',
  'ui.bootstrap',
  'testControllerMod',
  'ui.grid',
  'ui.grid.pagination'
]);


var testControllerMod = angular.module('testControllerMod', []);



