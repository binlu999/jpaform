


// alert("begin test controller");




testControllerMod.controller('testCtrl', function ($scope) {
	
	$scope.testvalue = "from test controller";

	// alert("end test controller");

});



// alert("end test controller");
