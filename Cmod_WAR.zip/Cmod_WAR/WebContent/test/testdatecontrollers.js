


//alert("begin test controller");




testControllerMod.controller('dateCtrl', function ($scope) {
	  $scope.today = function() {
	    $scope.dt = new Date();
	  };
	  $scope.today();

	  $scope.clear = function () {
	    $scope.dt = null;
	  };

	  // Disable weekend selection
	  $scope.disabled = function(date, mode) {
	    return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
	  };

	  $scope.toggleMin = function() {
	    $scope.minDate = $scope.minDate ? null : new Date();
	  };
	  $scope.toggleMin();
	  $scope.maxDate = new Date(2020, 5, 22);

	  $scope.open = function($event) {
	    $scope.status.opened = true;
	  };

	  $scope.setDate = function(year, month, day) {
	    $scope.dt = new Date(year, month, day);
	  };

	  $scope.dateOptions = {
	    formatYear: 'yy',
	    startingDay: 1
	  };

	  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
	  $scope.format = $scope.formats[0];

	  $scope.status = {
	    opened: false
	  };

	  var tomorrow = new Date();
	  tomorrow.setDate(tomorrow.getDate() + 1);
	  var afterTomorrow = new Date();
	  afterTomorrow.setDate(tomorrow.getDate() + 2);
	  $scope.events =
	    [
	      {
	        date: tomorrow,
	        status: 'full'
	      },
	      {
	        date: afterTomorrow,
	        status: 'partially'
	      }
	    ];

	  $scope.getDayClass = function(date, mode) {
	    if (mode === 'day') {
	      var dayToCheck = new Date(date).setHours(0,0,0,0);

	      for (var i=0;i<$scope.events.length;i++){
	        var currentDay = new Date($scope.events[i].date).setHours(0,0,0,0);

	        if (dayToCheck === currentDay) {
	          return $scope.events[i].status;
	        }
	      }
	    }

	    return '';
	  };
	});



testControllerMod.controller('dateCtrl2', function ($scope) {

	$scope.datePickers = {};
	
	$scope.getDatePicker = function(datePicker) {
		if ($scope.datePickers[datePicker] === undefined) {
			$scope.datePickers[datePicker] = { open : false };
		}
		return $scope.datePickers[datePicker];
	}

	$scope.toggleOpenDatePicker = function($event, _datePicker) {
		$event.preventDefault();
		$event.stopPropagation();
	
		var datePicker = $scope.getDatePicker(_datePicker);
		datePicker.open = !datePicker.open;
	}

	$scope.validatePastDate = function(value) {
		if (value !== undefined) {
			var now = new Date();
			now.setHours(23, 59, 59, 999);

			return value < now;
		}
		return true;
	}

	$scope.validateCurrentOrFutureDate = function(value) {
		if (value !== undefined) {
			var now = new Date();
			now.setHours(0, 0, 0, 0);

			return value >= now;
		}
		return true;
	}

});


testControllerMod.controller('dateCtrl3', function ($scope) {
	$scope.val = 'testval1';
	
	$scope.toggleOpenDatePicker = function($event, strparam) {
		alert("datepkr:"+strparam);
		var dtpkr = {open:true};
		
		return dtpkr;
	}
});


// alert("end test controller");



