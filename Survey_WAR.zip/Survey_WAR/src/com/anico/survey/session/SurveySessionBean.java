package com.anico.survey.session;

public class SurveySessionBean {
	
	 
	private String marketingArea = null;
	 
	
	 
	public String getMarketingArea() {
		return marketingArea;
	}
	public void setMarketingArea(String marketingArea) {
		this.marketingArea = marketingArea;
	}
 

}
