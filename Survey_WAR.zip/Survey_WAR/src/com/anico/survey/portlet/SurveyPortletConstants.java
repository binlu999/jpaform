package com.anico.survey.portlet;

import org.apache.log4j.Logger;

public class SurveyPortletConstants {

	// get reports list
	public final static String RESOURCE_ID_GET_REPORTS_LIST = "ResourceIdGetReportsList";
	public final static String RESOURCE_ID_GET_REPORTS_LIST_TEST = "ResourceIdGetReportsListTest";

	public final static String RESOURCE_ID_SEARCH_CMOD = "ResourceIdSearchCmod";

	public final static String RESOURCE_ID_DOWNLOAD_REPORT = "ResourceIdDownloadReport";
	public final static String RESOURCE_ID_DOWNLOAD_REPORT_TEST = "ResourceIdDownloadReportTest";

	public final static String RESOURCE_ID_SHOW_REPORT = "ResourceIdShowReport";
	public final static String RESOURCE_ID_SHOW_REPORT_TEST = "ResourceIdShowReportTest";

	public final static String RESOURCE_ID_GET_DOWNLINE = "ResourceIdGetDownline";

	public static Logger LOGSURVEY = Logger.getLogger("SURVEY");

	

	public final static String SEARCH_MAX_RETURN_SIZE = "-1";

	public final static String SEARCH_USERTYPE_AGENT = "AGENT";
	public final static String SEARCH_USERTYPE_STAFF = "STAFF";
	
	// search set by user
	public final static String SEARCH_USER_SEARCH_TYPE_PERSONAL = "personal";
	public final static String SEARCH_USER_SEARCH_TYPE_HIERARCHY = "hierarchy";

	// search types for cmod backend service
	public final static String SEARCH_TYPE_PERSONAL = "1"; // personal only
	public final static String SEARCH_TYPE_HIERARCHY = "2"; // personal +
															// hierarchy
	public final static String SEARCH_TYPE_SPECIFC = "3"; // specific agent only
	public final static String SEARCH_TYPE_COMBINED = "4";

	// submit types - FormSearch, QuickCategorySearch, QuickReportNameSearch,
	// DownlineSearch
	public final static String SUBMIT_TYPE_NONE = "";
	public final static String SUBMIT_TYPE_FORM = "FormSearch";
	public final static String SUBMIT_TYPE_QUICK_CATEGORY = "QuickCategorySearch";
	public final static String SUBMIT_TYPE_QUICK_REPORT_NAME = "QuickReportNameSearch";
	public final static String SUBMIT_TYPE_DOWNLINE = "DownlineSearch";

	public final static String CONFIG_FILE_NAME = "com.anico.survey.surveyErrorHandler";
	public final static String DB_CONFIG_NAME_DATA_MART = "dataMartDbManagerName";

	// from ctd constants
	public final static String HIERARCHY_SIGNAL = "N";

	// marketing area Constants
	public final static String MKT_IMO = "IMO";
	public final static String MKT_TERM = "TERM";
	public final static String MKT_MLM = "MLM";
	public final static String MKT_SLAICO = "SLAICO";

	// LDAP
	public final static String DEFAULT_USER_NAME = "User";
	public final static String LDAP_ATTRIBUTE_MARKETING_AREA = "MARKETINGAREA";
	public final static String LDAP_ATTRIBUTE_USER_NAME = "CN";
	public final static String LDAP_ATTRIBUTE_SSN = "ssn";

	// SCOPE ATTRIBUTES
	public final static String SCOPE_ATTRIB_UID = "uid";
	public final static String SCOPE_ATTRIB_USERNAME = "userName";
	public final static String SCOPE_ATTRIB_MARKETINGAREA = "marketingArea";
	public final static String SCOPE_ATTRIB_MANAGERFLAG = "managerFlag";

	public final static String DEFAULT_INDEX_PAGE = "/index.jsp";
	public final static String SERVICE_INTERRUPT_PAGE = "/serviceInterruptPage.jsp";

	public final static String PDF_MIME_CONTENT_TYPE_DEFINITION = "application/pdf";

	public final static String CONTENT_DISPOSITION = "Content-Disposition";

	public final static String CONTENT_TYPE = "attachment;";

	public final static String FILENAME = "filename=";

	public final static String PDF_EXTENSION = ".PDF";
	
	public final static String SEARCH_CATEGORY_ALL = "ALL";

	public final static String SEARCH_ALL_BEGIN_DATE = "2008-01-01";
	public final static String SEARCH_ALL_END_DATE = "2999-12-31";

	
	public final static String STATUS_OK = "OK";
	public final static String STATUS_NO_DOWNLINE_FOUND = "NO_DOWNLINE_FOUND";
	public final static String STATUS_NO_REPORTS_FOUND = "NO_REPORTS_FOUND";
	public final static String STATUS_SESSION_EXPIRED = "session_expired";
	public final static String STATUS_ERROR = "error";
	
	
	public final static String MSG_SESSION_EXPIRED = "Session has expired, refresh page.";
	public final static String MSG_ERROR = "Error in processing the request.";
	
	public static final String SERVICE_SESSION_TIMEOUT_INDICATOR = "pkmslogin.form";

}
