package com.anico.survey.portlet;

import static com.anico.survey.portlet.SurveyPortletConstants.CONFIG_FILE_NAME;
import static com.anico.survey.portlet.SurveyPortletConstants.DB_CONFIG_NAME_DATA_MART;
import static com.anico.survey.portlet.SurveyPortletConstants.LOGSURVEY;

import com.anico.dasd.CompoundProperty;
import com.anico.dasd.Environment;
import com.anico.dasd.ServletConfigReader;


import static com.anico.survey.portlet.SurveyPortletConstants.*;

public class SurveyPortletConfig {

	private final static String CONFIG_TAG_DB_DATA_MART_NAME = "dataMartDbManagerName";
	private final static String CONFIG_TAG_PDF_SERVICE_URL = "pdfServiceUrl";
	private final static String CONFIG_TAG_CMOD_SOAP_SERVICE_ENDPOINT_URL = "cmodSoapServiceEndpointUrl";
	private final static String DEFAULT_NOT_LOADED_VALUE = "NOT_LOADED_CHECK_CONFIG"; 
	
	
	private static String DB_DATA_MART_NAME = DEFAULT_NOT_LOADED_VALUE;
	private static String PDF_SERVICE_URL = DEFAULT_NOT_LOADED_VALUE;
	private static String CMOD_SOAP_SERVICE_ENDPOINT_URL = DEFAULT_NOT_LOADED_VALUE;
	

	static {
		try {
			CompoundProperty config = new ServletConfigReader(false)
					.readAndGetConfig(CONFIG_FILE_NAME);
			
			if (config == null) {
				LOGSURVEY.error("Survey config handle is null");
			} else {
				LOGSURVEY.info("Got handle to survey config");
			}
			
			String envStr = Environment.getEnvironmentString();
			LOGSURVEY.info("Survey Manager Environment is:"+envStr);
			
			DB_DATA_MART_NAME = config.getSimpleString(CONFIG_TAG_DB_DATA_MART_NAME);	
			LOGSURVEY.info("db data mart dsn name is:"+DB_DATA_MART_NAME);			
			
			
			PDF_SERVICE_URL = config.getSimpleString(CONFIG_TAG_PDF_SERVICE_URL);	
			LOGSURVEY.info("pdf service url is:"+PDF_SERVICE_URL);		
						
			CMOD_SOAP_SERVICE_ENDPOINT_URL = config.getSimpleString(CONFIG_TAG_CMOD_SOAP_SERVICE_ENDPOINT_URL);	
			LOGSURVEY.info("cmod soap service endpoint url is:"+CMOD_SOAP_SERVICE_ENDPOINT_URL);		
			
			
		} catch (Exception e) {
			 LOGSURVEY.error("exception in cmod config load:"+e.getMessage());
			 e.printStackTrace();
		} finally {
			LOGSURVEY.info("cmod config loaded");
		}
	}
	
	public static String getDbDataMartName() {
		return DB_DATA_MART_NAME;
	}
	
	public static String getPdfServiceUrl() {
		return PDF_SERVICE_URL;
	}
	
	public static String getCmodSoapServiceEndpointUrl() {
		return CMOD_SOAP_SERVICE_ENDPOINT_URL;
	}
	
	
}
