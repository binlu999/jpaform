package com.anico.survey.portlet;

import java.io.*;
import java.security.Principal;

import javax.portlet.*;

import com.anico.dasd.ConfiguredPortlet;
import com.anico.dasd.DASDConfigurationException;
import com.anico.survey.SurveyErrorHandler;
import com.anico.survey.session.SurveySessionBean;

import static com.anico.survey.portlet.SurveyPortletConstants.*;
import static com.anico.survey.portlet.SurveyUtils.*;
/**
 * A sample portlet
 */
public class SurveyPortletBackup extends ConfiguredPortlet {
	
	public SurveyPortletBackup() throws DASDConfigurationException {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see javax.portlet.Portlet#init()
	 */
	public void init() throws PortletException{
		super.init();
	}

	/**
	 * Serve up the <code>view</code> mode.
	 * 
	 * @see javax.portlet.GenericPortlet#doView(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		 
	 
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		 
		//
		// TODO: auto-generated method stub for demonstration purposes
		//
		
		// Invoke the JSP to render, replace with the actual jsp name
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher("/index.jsp");
		rd.include(request,response);
		
		// or write to the response directly
		//response.getWriter().println("Survey#doView()");
	}

	@Override
	public void serveResource(ResourceRequest request, ResourceResponse response)
			throws PortletException, IOException {
		// TODO Auto-generated method stub
		super.serveResource(request, response);
	}

	/**
	 * Serve up the <code>edit</code> mode.
	 * 
	 * @see javax.portlet.GenericPortlet#doEdit(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	public void doEdit(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// TODO: auto-generated method stub
	}

	/**
	 * Serve up the <code>help</code> mode.
	 * 
	 * @see javax.portlet.GenericPortlet#doHelp(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	protected void doHelp(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// TODO: auto-generated method stub
	}

	/**
	 * Process an action request.
	 * 
	 * @see javax.portlet.Portlet#processAction(javax.portlet.ActionRequest, javax.portlet.ActionResponse)
	 */
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		// TODO: auto-generated method stub
	}

	@Override
	protected String getErrorHandlerClassName() {
		return SurveyErrorHandler.class.getName();
	}

}
