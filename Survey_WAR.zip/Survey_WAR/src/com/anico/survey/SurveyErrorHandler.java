package com.anico.survey;

import com.anico.dasd.ConfiguredErrorHandler;
import com.anico.dasd.DASDConfigurationException;
import com.anico.dasd.ServletConfigReader;

public class SurveyErrorHandler extends ConfiguredErrorHandler{

	public SurveyErrorHandler() throws DASDConfigurationException {
		super(new ServletConfigReader(Boolean.FALSE.booleanValue())
		.readAndGetConfig(SurveyErrorHandler.class.getName()));
	}

}
