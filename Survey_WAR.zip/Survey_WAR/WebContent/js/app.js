
/* JavaScript content from js/app.js in folder common */
/**
 * 
 */

 // alert('appjs 2 from content');


var surveyNgApp = angular.module('surveyNgApp', [
  'ngRoute',
  'ui.bootstrap',
  'surveyControllerMod',
  'ngMessages'
]);


var surveyControllerMod = angular.module('surveyControllerMod', ['surveySvcMod']);

var surveySvcMod = angular.module("surveySvcMod",[]);



// alert('test1b'); 

// alert("cmodBaseUrl app:"+cmodBaseUrl);

surveyNgApp.config(['$routeProvider',
                    function($routeProvider) {
                      $routeProvider.
                        when('/search', {
                          templateUrl: surveyBaseUrl+ '/surveyform/searchView.html',
                          controller: 'surveySearchCtrl'
                        }).
                        when('/survey', {
                            templateUrl: cmodBaseUrl+ '/surveyform/surveyView.html',
                            controller: 'surveyFormCtrl'
                          }).  
                              
                        when('/error', {
                             templateUrl: surveyBaseUrl+ '/surveyform/errorView.html',
                             controller: 'surveyErrorCtrl'
                                }).                               
                        otherwise({
                          redirectTo: '/search'
                        });
                    }]);


// alert('test1ca');
